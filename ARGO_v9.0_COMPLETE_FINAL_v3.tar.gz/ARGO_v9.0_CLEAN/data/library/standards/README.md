# Industry Standards

Coloca aquí documentos de: Industry Standards

Estos documentos estarán disponibles desde todos los proyectos.

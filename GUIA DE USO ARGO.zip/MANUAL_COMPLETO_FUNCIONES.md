# 📖 ARGO - Manual Completo de Funciones

**Todas las Capacidades del Sistema - Guía para Usuario Final**

---

## 📑 Índice de Funciones

1. [Gestión de Proyectos](#1-gestión-de-proyectos)
2. [Sistema de Chat Inteligente](#2-sistema-de-chat-inteligente)
3. [Gestión de Documentos](#3-gestión-de-documentos)
4. [Biblioteca de Conocimiento](#4-biblioteca-de-conocimiento)
5. [Análisis de Cronogramas](#5-análisis-de-cronogramas)
6. [Búsqueda Avanzada (RAG)](#6-búsqueda-avanzada-rag)
7. [Memoria y Contexto](#7-memoria-y-contexto)
8. [Analytics y Reportes](#8-analytics-y-reportes)
9. [Integración con Google Drive](#9-integración-con-google-drive)
10. [Funciones Avanzadas](#10-funciones-avanzadas)

---

## 1. Gestión de Proyectos

### 1.1 Crear Nuevo Proyecto

**Qué Hace:** Crea un espacio aislado para tu proyecto.

**Cómo Usarlo:**
1. En la interfaz, selecciona "Create New Project"
2. Ingresa nombre del proyecto: `Central_Nuclear_A`
3. Selecciona tipo:
   - **Standard:** Proyecto normal
   - **ED/STO:** Emergency Deployment, Shutdown, Turnaround, Outage
   - **Library:** Para documentos compartidos

**Qué Obtienes:**
- Espacio dedicado con sus propios documentos
- Historial de conversaciones separado
- Análisis independientes
- Memoria específica del proyecto

**Ejemplo:**
```
Proyecto: "Ampliación Planta Solar 2025"
Tipo: Standard
Resultado: Nuevo espacio listo para subir documentos y chatear
```

---

### 1.2 Cambiar Entre Proyectos

**Qué Hace:** Alterna entre diferentes proyectos sin perder contexto.

**Cómo Usarlo:**
1. En el menú lateral, selecciona "Select Project"
2. Elige de la lista de proyectos existentes
3. El sistema carga todo el contexto de ese proyecto

**Qué Obtienes:**
- Acceso inmediato a todos los documentos del proyecto
- Historial de conversaciones del proyecto
- Análisis previos del proyecto
- Memoria específica del proyecto

**Importante:** Los proyectos están AISLADOS. Lo que haces en uno NO afecta al otro.

---

### 1.3 Tipos de Proyectos

#### Standard (Proyecto Normal)
- Para cualquier proyecto tradicional
- Sin configuraciones especiales
- Ideal para: Construcción, IT, desarrollo, etc.

#### ED/STO (Emergency Deployment / Shutdown / Turnaround / Outage)
- Optimizado para paradas de planta
- Enfoque en criticidad y tiempo
- Búsqueda prioritaria de:
  - Work packages
  - Critical path
  - Resource constraints
  - Safety procedures

#### Library (Biblioteca Compartida)
- NO es un proyecto real
- Es un repositorio de conocimiento general
- Disponible para TODOS los proyecos
- Ideal para: Estándares, procedimientos, templates

---

## 2. Sistema de Chat Inteligente

### 2.1 Chat Básico

**Qué Hace:** Conversa con ARGO como con un experto.

**Cómo Usarlo:**
```
Tú: ¿Qué es la ruta crítica?

ARGO: La ruta crítica es la secuencia más larga de actividades...
[Con referencias a tus documentos si los tienes]
```

**Capacidades:**
- Responde preguntas sobre gestión de proyectos
- Explica conceptos de PMI, AACE, DCMA
- Busca en TUS documentos automáticamente
- Cita las fuentes

---

### 2.2 Chat con Contexto de Documentos (RAG)

**Qué Hace:** Responde basándose en TUS documentos específicos.

**Cómo Funciona:**
1. Subes documentos a tu proyecto
2. Preguntas algo
3. ARGO busca en tus documentos
4. Te responde con información de TUS archivos
5. Te muestra DE DÓNDE sacó la información

**Ejemplo:**
```
Tú: ¿Cuál es nuestro procedimiento de control de cambios?

ARGO: Según el documento "PM-PROC-001-Control-Cambios.pdf":
"Todo cambio debe seguir el siguiente proceso:
1. Solicitud formal en formato CC-001
2. Evaluación de impacto por PMO
3. Aprobación del sponsor..."

Fuente: PM-PROC-001-Control-Cambios.pdf, página 7
```

---

### 2.3 Preguntas Sobre Proyectos Específicos

**Qué Hace:** Consultas sobre proyecto actual.

**Ejemplos de Uso:**
```
✅ "¿Qué documentos tengo subidos en este proyecto?"
✅ "¿Cuál fue el último análisis que hiciste?"
✅ "¿Qué conversamos ayer sobre riesgos?"
✅ "Resúmeme el estado actual del proyecto"
✅ "¿Qué archivos XER he analizado?"
```

**Qué Obtienes:**
- Lista de documentos del proyecto
- Historial de análisis
- Resumen de conversaciones anteriores
- Estado actualizado del proyecto

---

### 2.4 Selección de Modelo IA

**Qué Hace:** Elige qué "cerebro" de IA usar.

**Modelos Disponibles:**

#### GPT-4o (OpenAI)
- **Mejor para:** Análisis técnicos, cálculos, código
- **Velocidad:** Rápido (2-5 segundos)
- **Tokens:** 128K contexto
- **Costo:** Medio

#### GPT-4o-mini (OpenAI)
- **Mejor para:** Consultas simples, búsquedas rápidas
- **Velocidad:** Muy rápido (1-2 segundos)
- **Tokens:** 128K contexto
- **Costo:** Bajo

#### Claude Sonnet 4 (Anthropic)
- **Mejor para:** Escritura, análisis profundo, contexto largo
- **Velocidad:** Medio (5-10 segundos)
- **Tokens:** 200K contexto
- **Costo:** Alto

**Cómo Elegir:**
- **Modo Auto:** ARGO elige por ti (recomendado)
- **Manual:** Tú seleccionas el modelo

**Ejemplo:**
```
Consulta rápida de dato → GPT-4o-mini
Análisis de cronograma → GPT-4o
Escribir informe largo → Claude Sonnet 4
```

---

## 3. Gestión de Documentos

### 3.1 Subir Documentos

**Qué Hace:** Añade archivos a tu proyecto.

**Formatos Soportados:**
- ✅ PDF (contratos, reportes, manuales)
- ✅ Word (.docx) (procedimientos, informes)
- ✅ Excel (.xlsx) (listas, datos, presupuestos)
- ✅ Texto (.txt, .md)
- ✅ XER (Primavera P6)
- ✅ MPP (Microsoft Project)

**Cómo Usarlo:**
1. Ve a "Files Management"
2. Click en "Upload Files"
3. Selecciona uno o varios archivos
4. Espera a que se procesen (1-60 segundos por archivo)
5. ¡Listo! Ya puedes hacer preguntas sobre ellos

**Qué Pasa Internamente:**
1. Archivo se guarda en el proyecto
2. Se extrae el texto completo
3. Se divide en fragmentos inteligentes (chunks)
4. Se crean embeddings vectoriales
5. Se guarda en la base de datos vectorial
6. Ahora es buscable por IA

**Límites:**
- Tamaño máximo: Configurable (default: 50 MB/archivo)
- Cantidad: Ilimitada (depende de espacio en disco)

---

### 3.2 Ver Documentos del Proyecto

**Qué Hace:** Lista todos los documentos en el proyecto actual.

**Información Mostrada:**
- Nombre del archivo
- Tipo de archivo
- Fecha de subida
- Tamaño
- Estado de procesamiento
- Número de chunks (fragmentos)

**Cómo Usarlo:**
1. Ve a "Files Management"
2. Ve la lista completa
3. Puedes filtrar por tipo o fecha

---

### 3.3 Eliminar Documentos

**Qué Hace:** Remueve un documento del proyecto.

**Cómo Usarlo:**
1. Ve a "Files Management"
2. Selecciona el documento a eliminar
3. Click en "Delete"
4. Confirma la acción

**Qué Se Elimina:**
- El archivo físico
- Los chunks en la base de datos vectorial
- Los embeddings
- Referencias en conversaciones (marcadas como eliminadas)

---

### 3.4 Procesamiento Automático

**Qué Hace:** Extrae y prepara documentos automáticamente.

**Para Cada Tipo de Documento:**

#### PDF
- Extrae texto completo
- Mantiene estructura
- Identifica tablas
- Preserva formato

#### Word (DOCX)
- Extrae texto y formato
- Mantiene estructura de secciones
- Procesa tablas
- Extrae imágenes con texto (OCR básico)

#### Excel (XLSX)
- Procesa cada hoja
- Convierte tablas a texto estructurado
- Mantiene relaciones de datos
- Interpreta fórmulas (como valores)

#### XER/MPP (Cronogramas)
- Extrae actividades completas
- Procesa relaciones (lógica)
- Identifica ruta crítica
- Calcula métricas básicas

**Chunking Inteligente:**
- Divide documentos en fragmentos óptimos
- Preserva contexto semántico
- Ajusta tamaño según tipo de documento
- Evita cortar en mitad de frases/tablas

---

## 4. Biblioteca de Conocimiento

### 4.1 ¿Qué es la Biblioteca?

**Definición:** Repositorio de conocimiento GENERAL disponible para TODOS los proyectos.

**Diferencia con Proyectos:**
- **Proyecto:** Documentos específicos de UN proyecto
- **Biblioteca:** Conocimiento general usado en TODOS los proyectos

**Contenido Típico:**
- Estándares PMI (PMBOK, Practice Guides)
- Estándares AACE (TCM Framework, Cost Engineering)
- Guías DCMA (14-Point, 16-Point)
- Políticas corporativas
- Templates y formularios
- Mejores prácticas
- Lecciones aprendidas organizacionales

---

### 4.2 Organización de la Biblioteca

**Categorías Automáticas:**

```
library/
├── pmi_standards/          # PMI: PMBOK, Practice Guides
├── aace_standards/         # AACE: TCM, Cost Engineering
├── dcma_guidelines/        # DCMA: Schedule Analysis
├── company_policies/       # Políticas de tu empresa
├── templates/              # Formularios y templates
├── procedures/             # Procedimientos generales
├── lessons_learned/        # Lecciones aprendidas
└── best_practices/         # Mejores prácticas
```

**Auto-Categorización:**
ARGO detecta automáticamente la categoría por:
- Nombre del archivo
- Contenido del documento
- Metadata

---

### 4.3 Subir a Biblioteca

**Qué Hace:** Añade documentos a la biblioteca compartida.

**Cómo Usarlo:**
1. Crea/selecciona proyecto tipo "Library"
2. Sube documentos normalmente
3. ARGO los categoriza automáticamente
4. Quedan disponibles para todos los proyectos

**Ejemplo:**
```
Subes: "PMBOK_Guide_7th_Edition.pdf"
→ Auto-categorizado en: pmi_standards/
→ Disponible en TODOS los proyectos
```

---

### 4.4 Búsqueda Cross-Project

**Qué Hace:** Busca en proyecto actual Y en biblioteca simultáneamente.

**Cómo Funciona:**
```
Tú: ¿Qué dice el PMBOK sobre gestión de riesgos?

ARGO busca en:
1. Documentos del proyecto actual (prioridad alta)
2. Biblioteca general (prioridad media)

Resultado combinado con fuentes claras de cada una
```

**Priorización Automática:**
- Documentos del proyecto: 100% relevancia
- Biblioteca con boost: 80% relevancia
- Balance automático entre ambos

---

### 4.5 Library Boost

**Qué Hace:** Da más peso a ciertos documentos de biblioteca.

**Documentos con Boost Automático:**
- PMBOK (PMI)
- TCM Framework (AACE)
- DCMA Guidelines
- ISO Standards
- Políticas corporativas marcadas como "mandatory"

**Ejemplo:**
```
Búsqueda: "risk management"

Sin Boost:
- Resultado 1: Email de proyecto (score: 0.85)
- Resultado 2: PMBOK (score: 0.82)

Con Boost:
- Resultado 1: PMBOK (score: 0.82 × 1.2 = 0.98)
- Resultado 2: Email de proyecto (score: 0.85)

PMBOK gana prioridad ✓
```

---

## 5. Análisis de Cronogramas

### 5.1 Subir Cronograma (XER/MPP)

**Qué Hace:** Importa y analiza archivos de Primavera P6 o MS Project.

**Formatos Soportados:**
- ✅ XER (Primavera P6) - Recomendado
- ✅ MPP (Microsoft Project)
- ✅ XML (P6 y MSP)

**Cómo Usarlo:**
1. Exporta cronograma desde P6/MSP
2. Sube archivo a ARGO (Files Management)
3. ARGO detecta automáticamente que es un cronograma
4. Procesamiento automático (10-60 segundos)
5. Listo para análisis

**Información Extraída:**
- Todas las actividades
- Predecesoras y sucesoras (lógica)
- Duraciones
- Fechas (Early/Late Start/Finish)
- Holguras (Total Float, Free Float)
- Ruta crítica
- Recursos asignados
- Calendarios
- WBS (Work Breakdown Structure)

---

### 5.2 Análisis Básico de Cronograma

**Qué Hace:** Análisis automático al subir.

**Métricas Calculadas:**
- **Total de actividades**
- **Actividades críticas** (TF = 0)
- **Actividades near-critical** (TF < 5 días)
- **Duración total del proyecto**
- **Longitud de ruta crítica**
- **% de actividades críticas**
- **Distribución de holguras**

**Ejemplo de Salida:**
```
Cronograma: "Central_Nuclear_A_Rev15.xer"

Resumen:
- Total actividades: 4,832
- Críticas: 387 (8%)
- Near-critical: 156 (3%)
- Duración proyecto: 845 días
- Ruta crítica: 823 días
- Float promedio: 47 días

Alertas:
⚠️ 8% de actividades críticas (alto)
⚠️ Ruta crítica = 97% duración total (muy ajustado)
✓ Distribución de float razonable
```

---

### 5.3 Análisis DCMA 14-Point

**Qué Hace:** Evaluación según DCMA 14-Point Assessment Guide.

**Los 14 Puntos Evaluados:**

1. **Logic:** Lógica completa (SS, FS, FF, SF)
2. **Leads:** Sin leads excesivos
3. **Lags:** Lags justificados
4. **Relationship Types:** Tipos de relaciones apropiados
5. **Hard Constraints:** Constraints minimizados
6. **High Float:** Float excesivo controlado
7. **Negative Float:** Sin float negativo
8. **High Duration:** Duraciones razonables
9. **Invalid Dates:** Fechas válidas
10. **Resources:** Recursos asignados
11. **Missed Tasks:** Tareas no completadas a tiempo
12. **Critical Path Test:** Ruta crítica validada
13. **Critical Path Length Index:** CPLI aceptable
14. **Baseline:** Baseline establecido

**Cómo Usarlo:**
```
Tú: Analiza este cronograma según DCMA 14-Point

ARGO: [Genera informe completo]

DCMA 14-Point Assessment
========================

1. Logic ✓ PASS (98% actividades con lógica)
2. Leads ⚠️ WARNING (15 leads encontrados)
3. Lags ✓ PASS (lags < 5% actividades)
...
14. Baseline ✗ FAIL (sin baseline actual)

Score: 10/14 (71%)
Clasificación: AMARILLO (requiere atención)
```

**Niveles de Clasificación:**
- **VERDE:** 12-14 puntos (Excelente)
- **AMARILLO:** 8-11 puntos (Aceptable con reservas)
- **ROJO:** 0-7 puntos (Inaceptable)

---

### 5.4 Identificación de Ruta Crítica

**Qué Hace:** Identifica y reporta la ruta crítica.

**Cómo Usarlo:**
```
Tú: ¿Cuál es la ruta crítica de este cronograma?

ARGO: La ruta crítica contiene 387 actividades:

1. [WBS 1.1.1] Site Mobilization (10d)
   → [WBS 1.2.1] Foundation Excavation (45d)
   → [WBS 1.2.3] Concrete Pouring (30d)
   ...
   → [WBS 9.8.5] Final Inspection (5d)

Duración total: 823 días
Activities driving critical path: [lista]
Recomendaciones: [análisis]
```

**Análisis Incluye:**
- Secuencia completa de actividades críticas
- Duraciones individuales
- Driving activities (las que más impactan)
- Paquetes de trabajo (WBS) en ruta crítica
- Recomendaciones para optimización

---

### 5.5 Detección de Problemas

**Qué Hace:** Identifica problemas comunes en cronogramas.

**Problemas Detectados:**

#### Lógica
- ❌ Actividades sin predecesoras
- ❌ Actividades sin sucesoras
- ❌ Open ends (inicio o fin)
- ❌ Lógica circular
- ❌ Lags excesivos (> 20 días)
- ❌ Leads (generalmente no recomendados)

#### Duraciones
- ❌ Actividades muy largas (> 44 días)
- ❌ Duraciones = 0
- ❌ Duraciones negativas

#### Fechas
- ❌ Constraints innecesarios (Must Finish On, etc.)
- ❌ Fechas en el pasado sin progreso
- ❌ Float negativo
- ❌ Fechas inválidas

#### Recursos
- ❌ Actividades sin recursos
- ❌ Recursos sobre-asignados
- ❌ Recursos fantasma (no existen en resource pool)

**Ejemplo de Reporte:**
```
Problemas Detectados: 47

CRÍTICO (15):
- 8 actividades sin predecesoras
- 5 actividades con float negativo
- 2 loops de lógica

ALTO (18):
- 12 actividades > 44 días
- 6 lags > 20 días

MEDIO (14):
- 14 actividades sin recursos
```

---

### 5.6 Análisis de Float

**Qué Hace:** Analiza distribución de holguras.

**Métricas:**
- Float promedio
- Float mediana
- Distribución por rangos
- Actividades con float excesivo (> 100 días)
- Actividades critical/near-critical

**Ejemplo de Visualización:**
```
Distribución de Total Float:

Float = 0 días (Crítico):    387 actividades (8%)
Float 1-5 días:               156 actividades (3%)
Float 6-20 días:              892 actividades (18%)
Float 21-44 días:           1,245 actividades (26%)
Float 45-100 días:          1,689 actividades (35%)
Float > 100 días:             463 actividades (10%)

Promedio: 47 días
Mediana: 35 días

⚠️ Alerta: 10% con float > 100 días (revisar integración)
```

---

### 5.7 Recomendaciones de Optimización

**Qué Hace:** Sugiere mejoras basadas en análisis.

**Tipos de Recomendaciones:**

#### Compresión de Cronograma
```
"Actividad X123 (45d) está en ruta crítica.
Considerar:
- Fast-tracking con actividad siguiente
- Crashing con recursos adicionales
- Revisión de duración (¿es realista 45d?)"
```

#### Mejora de Lógica
```
"Actividad Y456 tiene 5 predecesoras tipo FS.
Posible over-constraint.
Revisar si todas las relaciones son necesarias."
```

#### Balance de Recursos
```
"Recurso 'Crane-001' sobre-asignado 150% en semana 23.
Considerar:
- Extender duración de actividades
- Adicionar recurso similar
- Re-secuenciar trabajo"
```

---

## 6. Búsqueda Avanzada (RAG)

### 6.1 Búsqueda Semántica

**Qué Hace:** Busca por SIGNIFICADO, no solo palabras exactas.

**Ejemplo:**
```
Búsqueda tradicional (palabra clave):
"risk management" → Solo encuentra documentos con esas palabras exactas

Búsqueda semántica (ARGO):
"risk management" → Encuentra:
- "gestión de riesgos"
- "uncertainty handling"
- "threat and opportunity assessment"
- "contingency planning"
```

**Ventaja:** Encuentra información relevante aunque use palabras diferentes.

---

### 6.2 HyDE (Hypothetical Document Embeddings)

**Qué Hace:** Mejora búsqueda generando documento hipotético.

**Cómo Funciona:**
1. Pregunta: "¿Cómo se calcula el CPM?"
2. ARGO genera respuesta hipotética:
   "El Critical Path Method (CPM) se calcula mediante forward pass y backward pass..."
3. Busca documentos similares a esa respuesta (no a la pregunta)
4. Encuentra mejores resultados

**Ventaja:** Supera el "vocabulary mismatch" entre pregunta y documento.

**Ejemplo:**
```
Sin HyDE:
Pregunta: "¿cómo acelero proyecto?"
Busca: "cómo acelero proyecto"
Resultados: Limitados

Con HyDE:
Pregunta: "¿cómo acelero proyecto?"
Genera respuesta hipotética: "Para acelerar un proyecto se usan técnicas de crashing, fast-tracking, optimización de recursos..."
Busca: Documentos sobre esas técnicas
Resultados: Mucho mejores ✓
```

---

### 6.3 Caché Semántico

**Qué Hace:** Recuerda búsquedas anteriores similares.

**Cómo Funciona:**
1. Primera vez preguntas: "¿Qué es ruta crítica?"
   - ARGO busca en todos los documentos (3 segundos)
   - Guarda resultado en caché

2. Luego preguntas: "Explícame ruta crítica"
   - ARGO detecta pregunta similar (90% match)
   - Usa resultado cacheado (0.1 segundos)
   - 30x más rápido ✓

**Beneficios:**
- Respuestas instantáneas para preguntas repetidas
- Ahorro de costos de API
- Mejor experiencia de usuario

**Duración del Caché:**
- Default: 24 horas
- Se invalida si subes nuevos documentos
- Configurable por administrador

---

### 6.4 Re-ranking

**Qué Hace:** Reordena resultados para máxima relevancia.

**Proceso:**
1. **Primera búsqueda:** Encuentra 20 documentos candidatos
2. **Re-ranking:** Los analiza en detalle
3. **Reordena:** Pone los MÁS relevantes primero
4. **Devuelve:** Top 5 con mejor relevancia

**Ejemplo:**
```
Búsqueda inicial (20 resultados):
1. Score: 0.78 - "Risk register template"
2. Score: 0.76 - "Monthly status report"
3. Score: 0.75 - "Risk management plan"
...

Después de Re-ranking:
1. Score: 0.92 - "Risk management plan" ⬆️
2. Score: 0.88 - "Risk register template" ⬇️
3. Score: 0.85 - "Lessons learned - Risks" ⬆️
...
```

**Resultado:** Los documentos MÁS útiles siempre están primero.

---

### 6.5 Normalización de Scores

**Qué Hace:** Hace comparables los resultados de diferentes fuentes.

**Problema Sin Normalización:**
```
Proyecto actual:  Score 0.85
Biblioteca:       Score 0.62

¿Cuál es mejor? Difícil de saber...
```

**Con Normalización:**
```
Proyecto actual:  Score 0.85 (normalizado 0.90)
Biblioteca:       Score 0.62 (normalizado 0.88 con boost)

Ahora es comparable y justo ✓
```

**Ventaja:** Resultados de biblioteca y proyecto compiten en igualdad de condiciones.

---

### 6.6 Búsqueda Multi-Proyecto

**Qué Hace:** Busca en varios proyectos simultáneamente.

**Cómo Usarlo:**
```
Tú: Busca "lessons learned" en todos los proyectos

ARGO: Buscando en 5 proyectos activos...

Resultados:
[Proyecto A] 3 documentos encontrados
[Proyecto B] 7 documentos encontrados
[Proyecto C] 1 documento encontrado
[Biblioteca] 12 documentos encontrados

Mostrando top 10 consolidados...
```

**Uso Típico:**
- Buscar lecciones aprendidas en proyectos anteriores
- Encontrar precedentes de situaciones similares
- Comparar enfoques entre proyectos

---

## 7. Memoria y Contexto

### 7.1 Historial de Conversaciones

**Qué Hace:** Guarda TODAS tus conversaciones por proyecto.

**Almacenamiento:**
- Cada pregunta y respuesta
- Timestamp exacto
- Modelo usado
- Documentos consultados
- Tokens consumidos

**Cómo Acceder:**
```
Tú: ¿Qué hablamos ayer sobre riesgos?

ARGO: Ayer discutimos:
1. Identificación de riesgos principales
2. Matriz de probabilidad/impacto
3. Estrategias de mitigación para top 5 riesgos

¿Quieres que continúe con alguno de esos temas?
```

---

### 7.2 Continuidad Entre Sesiones

**Qué Hace:** Recuerda contexto incluso después de cerrar/abrir.

**Ejemplo:**
```
Lunes 9am:
Tú: Analiza el cronograma XYZ.xer
ARGO: [Análisis completo]

[Cierras ARGO]

Martes 2pm:
Tú: Sobre ese cronograma que analizamos ayer...
ARGO: Sí, el cronograma XYZ.xer con 4,832 actividades.
      Encontramos 47 problemas. ¿Qué aspecto quieres revisar?
```

**ARGO recuerda TODO:**
- Análisis anteriores
- Documentos discutidos
- Decisiones tomadas
- Problemas identificados

---

### 7.3 Memoria por Proyecto

**Qué Hace:** Aísla la memoria de cada proyecto.

**Ventaja:**
```
Proyecto A: "el cronograma" = Schedule_ProjectA_v5.xer
Proyecto B: "el cronograma" = Schedule_ProjectB_v3.xer

ARGO NO confunde ✓
```

**Cambio de Contexto:**
```
[Trabajando en Proyecto A]
Tú: El cronograma tiene 200 actividades críticas

[Cambias a Proyecto B]
Tú: El cronograma tiene 50 actividades críticas

ARGO mantiene ambos contextos separados ✓
```

---

### 7.4 Referencias a Conversaciones Anteriores

**Qué Hace:** Puedes referenciar conversaciones previas.

**Ejemplos:**
```
✅ "Como discutimos la semana pasada..."
✅ "Según el análisis que hiciste ayer..."
✅ "Recuerdas el problema que identificaste..."
✅ "Basándote en lo que acordamos antes..."
```

**ARGO Responde:**
- Recupera la conversación anterior
- Aplica el mismo contexto
- Continúa desde donde quedaron
- Mantiene coherencia

---

### 7.5 Análisis de Historial

**Qué Hace:** Insights sobre tu uso de ARGO.

**Métricas Disponibles:**
- Temas más consultados
- Documentos más referenciados
- Preguntas frecuentes
- Evolución del proyecto (timeline de conversaciones)

**Ejemplo:**
```
Tú: ¿Cuáles son mis temas más consultados este mes?

ARGO: Tus top 5 temas en Noviembre:
1. Schedule analysis (47 conversaciones)
2. Risk management (23 conversaciones)
3. DCMA guidelines (18 conversaciones)
4. Resource leveling (12 conversaciones)
5. Change control (9 conversaciones)
```

---

## 8. Analytics y Reportes

### 8.1 Dashboard de Uso

**Qué Hace:** Visualiza tu uso del sistema.

**Métricas Mostradas:**
- Conversaciones por día
- Tokens consumidos
- Costo estimado
- Modelos más usados
- Proyectos más activos
- Documentos más consultados

**Visualización:**
- Gráficos de línea (tendencias)
- Gráficos de barras (comparaciones)
- Tablas de datos
- Exportable a Excel/PDF

---

### 8.2 Uso por Proyecto

**Qué Hace:** Compara actividad entre proyectos.

**Información:**
```
Proyecto            Conversaciones    Documentos    Costo
Central Nuclear A         247            127        $45.20
Planta Solar B            89              34        $12.50
Library                   156             89        $18.75
```

**Uso:**
- Identificar proyectos más activos
- Justificar inversión
- Planear recursos

---

### 8.3 Uso por Modelo

**Qué Hace:** Analiza qué modelos de IA usas más.

**Breakdown:**
```
Modelo          Llamadas    Tokens      Costo      Latencia Avg
GPT-4o           1,247    12.4M       $42.30         3.2s
GPT-4o-mini        892     2.1M        $3.50         1.8s
Claude S4          234     8.9M       $28.90         7.1s
```

**Insights:**
- Optimizar costos
- Balancear uso
- Identificar patrones

---

### 8.4 Alertas de Presupuesto

**Qué Hace:** Te avisa cuando te acercas a límite de gasto.

**Configuración:**
```
Presupuesto mensual: $100
Alerta al: 80% ($80)
Alerta crítica: 95% ($95)
```

**Notificaciones:**
```
⚠️ Has usado $82 de $100 este mes (82%)
📊 Proyección: $98 al fin de mes
💡 Sugerencia: Usar más GPT-4o-mini para reducir costos
```

---

### 8.5 Reportes de Proyecto

**Qué Hace:** Genera reportes automáticos de proyecto.

**Contenido:**
- Resumen ejecutivo
- Conversaciones clave
- Análisis realizados
- Documentos consultados
- Decisiones registradas
- Problemas identificados
- Recomendaciones

**Formato de Exportación:**
- PDF (presentable)
- Word (editable)
- Excel (datos)
- Markdown (integración)

**Ejemplo de Uso:**
```
Tú: Genera reporte mensual del proyecto

ARGO: [Crea documento con]:
=============================
REPORTE MENSUAL - PROYECTO X
Noviembre 2025
=============================

RESUMEN EJECUTIVO
- 47 conversaciones realizadas
- 12 documentos analizados
- 3 cronogramas evaluados
- 23 problemas identificados
- 18 recomendaciones generadas

ANÁLISIS PRINCIPALES
1. Schedule Analysis (Nov 5)
   - 4,832 actividades
   - 387 críticas
   - Score DCMA: 10/14
   
...
```

---

## 9. Integración con Google Drive

### 9.1 Configuración Inicial

**Qué Hace:** Conecta ARGO con tu Google Drive.

**Pasos:**
1. Habilitar Google Drive API
2. Crear credenciales OAuth
3. Descargar credentials.json
4. Colocar en carpeta de ARGO
5. Autorizar acceso (primera vez)
6. ¡Listo!

**Resultado:**
- ARGO puede leer de Drive
- ARGO puede escribir a Drive
- Sincronización automática (opcional)

---

### 9.2 Sincronización Automática de Biblioteca

**Qué Hace:** Mantiene biblioteca sincronizada con carpeta de Drive.

**Configuración:**
```yaml
apis:
  google_drive:
    enabled: true
    library_folder_id: "1aBcDeFgHiJk"  # ID de carpeta Drive
    sync_interval: 3600  # Cada hora
    auto_categorize: true
```

**Funcionamiento:**
1. Cada hora, ARGO revisa carpeta de Drive
2. Detecta archivos nuevos o modificados (MD5)
3. Descarga solo lo que cambió
4. Procesa y añade a biblioteca
5. Disponible inmediatamente

**Ventaja:**
- Equipo sube a Drive
- ARGO sincroniza automáticamente
- Sin intervención manual

---

### 9.3 Categorización Automática

**Qué Hace:** Organiza archivos de Drive en categorías.

**Detección por Nombre:**
```
Archivo: "PMBOK_Guide_7th.pdf"
→ Detecta: "PMBOK"
→ Categoría: pmi_standards/

Archivo: "Procedure_Change_Control.docx"
→ Detecta: "Procedure"
→ Categoría: procedures/

Archivo: "DCMA_14_Point_Guide.pdf"
→ Detecta: "DCMA"
→ Categoría: dcma_guidelines/
```

**Detección por Subcarpetas:**
```
Drive: /ARGO_Library/PMI/PMBOK_7.pdf
→ Categoría: pmi_standards/

Drive: /ARGO_Library/Templates/RBS.xlsx
→ Categoría: templates/
```

---

### 9.4 Watch for Changes

**Qué Hace:** Notificaciones instantáneas de cambios.

**Cómo Funciona:**
1. ARGO se registra para notificaciones de Drive
2. Alguien sube/modifica archivo en Drive
3. Google notifica a ARGO inmediatamente
4. ARGO descarga y procesa
5. Disponible en 10-30 segundos

**Ventaja:** No espera sincronización periódica, es casi instantáneo.

---

### 9.5 Subir Análisis a Drive

**Qué Hace:** Guarda reportes/análisis en Drive automáticamente.

**Configuración:**
```yaml
google_drive:
  auto_upload_reports: true
  reports_folder_id: "1xYzAbC..."
```

**Ejemplo:**
```
Tú: Analiza este cronograma

ARGO: [Realiza análisis]
      [Genera reporte PDF]
      [Sube automáticamente a Drive]
      
"Reporte guardado en: Drive/ARGO_Reports/Schedule_Analysis_2025-11-17.pdf"
```

---

## 10. Funciones Avanzadas

### 10.1 Evaluación Automática

**Qué Hace:** Sistema de testing automático de calidad.

**Casos de Prueba:**
- Preguntas predefinidas
- Respuestas esperadas
- Documentos de referencia

**Ejecución:**
```bash
python evaluation/evaluate.py
```

**Resultado:**
```
ARGO Evaluation Report
======================

Test 1: Basic PMI Question
Query: "What is the critical path method?"
Expected: "CPM is a technique to identify..."
Actual: "The Critical Path Method (CPM)..."
Score: 92/100 ✓

Test 2: Project-specific
Query: "List activities in critical path"
Expected: [List from project]
Actual: [Matching list]
Score: 98/100 ✓

...

Overall Score: 94/100
Status: PASS ✓
```

**Uso:**
- Verificar calidad después de cambios
- Comparar diferentes configuraciones
- Garantizar consistencia

---

### 10.2 Migración de Versiones

**Qué Hace:** Actualiza de versiones anteriores.

**Comando:**
```bash
python scripts/migrate_to_clean.py
```

**Proceso:**
1. Detecta versión actual
2. Backup automático
3. Migra base de datos
4. Actualiza estructura de archivos
5. Verifica integridad
6. Genera reporte

**Seguridad:**
- Zero pérdida de datos
- Rollback disponible
- Verificación exhaustiva

---

### 10.3 Auditoría de Arquitectura

**Qué Hace:** Verifica integridad del sistema.

**Comando:**
```bash
python scripts/audit_architecture.py
```

**Verificaciones:**
- Código duplicado (0% esperado)
- Imports correctos
- Consistencia de nombres
- Centralización de patrones
- LLM call traceability

**Resultado:**
```
ARGO Architecture Audit
=======================

✓ Code Duplication: 0%
✓ Naming Conventions: 100%
✓ Centralized Config: OK
✓ LLM Traceability: 100%
⚠️ Emojis in production: 2 files

Score: 95/100
Grade: A+
Status: PRODUCTION READY ✓
```

---

### 10.4 Batch Processing

**Qué Hace:** Procesa múltiples archivos automáticamente.

**Uso:**
```python
from tools.extractors import batch_process_directory

results = batch_process_directory(
    directory="path/to/documents",
    project_id="my_project",
    recursive=True
)

# Procesa todo el directorio automáticamente
```

**Ventaja:**
- Sube 100+ documentos de una vez
- Procesamiento paralelo
- Manejo automático de errores
- Progress tracking

---

### 10.5 Custom Prompts

**Qué Hace:** Personaliza comportamiento de IA.

**Configuración:**
```yaml
prompts:
  system_prompt: |
    You are a PMI-certified expert specializing in...
    
  analysis_prompt: |
    When analyzing schedules, focus on...
    
  report_format: |
    Generate reports in the following format...
```

**Uso:**
- Adaptar ARGO a metodología específica
- Personalizar estilo de respuestas
- Enforcar políticas corporativas

---

### 10.6 API Rest (Futuro)

**Qué Hará:** Acceso programático a ARGO.

**Endpoints Planeados:**
```
POST /api/v1/projects/{id}/chat
GET  /api/v1/projects/{id}/documents
POST /api/v1/projects/{id}/documents/upload
GET  /api/v1/projects/{id}/analysis/{analysis_id}
POST /api/v1/schedules/analyze
```

**Uso:**
- Integración con otros sistemas
- Automatización de workflows
- Desarrollo de aplicaciones custom

---

## 📊 Resumen de Capacidades

### Gestión
- ✅ Múltiples proyectos aislados
- ✅ 3 tipos de proyecto (standard, ED/STO, library)
- ✅ Cambio fluido entre proyectos
- ✅ Memoria persistente por proyecto

### Documentos
- ✅ PDF, Word, Excel, TXT
- ✅ XER (P6), MPP (MS Project)
- ✅ Procesamiento automático
- ✅ Chunking inteligente
- ✅ Búsqueda semántica

### Chat IA
- ✅ Dual LLM (GPT-4 + Claude)
- ✅ Selección automática de modelo
- ✅ RAG con documentos propios
- ✅ Cita fuentes siempre
- ✅ Memoria entre sesiones

### Biblioteca
- ✅ Conocimiento compartido
- ✅ Auto-categorización
- ✅ Cross-project search
- ✅ Library boost
- ✅ Sincronización Drive

### Cronogramas
- ✅ Import XER/MPP
- ✅ Análisis automático
- ✅ DCMA 14-Point
- ✅ Ruta crítica
- ✅ Detección de problemas
- ✅ Recomendaciones

### RAG Avanzado
- ✅ Búsqueda semántica
- ✅ HyDE
- ✅ Caché semántico
- ✅ Re-ranking
- ✅ Normalización de scores
- ✅ Multi-proyecto

### Analytics
- ✅ Dashboard de uso
- ✅ Métricas por proyecto
- ✅ Breakdown por modelo
- ✅ Alertas de presupuesto
- ✅ Reportes automáticos

### Integraciones
- ✅ Google Drive sync
- ✅ Auto-categorización
- ✅ Watch for changes
- ✅ Upload de reportes

### Avanzado
- ✅ Evaluación automática
- ✅ Migración de versiones
- ✅ Auditoría de arquitectura
- ✅ Batch processing
- ✅ Custom prompts

---

## 🎓 Conclusión

**ARGO es una plataforma completa** que combina:
- Gestión de proyectos
- Inteligencia artificial avanzada
- Gestión de conocimiento
- Análisis de cronogramas
- Analytics y reportes

**Todo en una sola interfaz**, diseñada para profesionales de proyectos que necesitan:
- Acceso rápido a información
- Análisis automatizados
- Consistencia con estándares
- Trazabilidad completa
- Memoria perfecta

**¿Listo para empezar?**
- Instala ARGO (INSTALL.md)
- Crea tu primer proyecto
- Sube algunos documentos
- ¡Empieza a preguntar!

---

**Manual Completo de Funciones - v9.0**  
*Última actualización: Noviembre 17, 2025*

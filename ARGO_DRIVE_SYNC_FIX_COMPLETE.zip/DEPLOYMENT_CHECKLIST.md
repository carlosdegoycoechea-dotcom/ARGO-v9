# ✅ CHECKLIST DE DEPLOYMENT - ARGO DRIVE SYNC FIX

## PRE-DEPLOYMENT (5 minutos)

### [ ] 1. Backup Actual
```bash
cd ARGO_v9.0_CLEAN
cp core/drive_manager.py core/drive_manager_BACKUP_$(date +%Y%m%d_%H%M%S).py
```
**Verificar**: Archivo backup existe
```bash
ls -lh core/drive_manager_BACKUP_*.py
```

### [ ] 2. Verificar Credenciales de Google
```bash
ls -lh config/google_credentials.json
```
**Debe existir**: Service account credentials configurado

### [ ] 3. Verificar Base de Datos
```bash
ls -lh data/argo.db
```
**Debe existir**: Unified database operacional

### [ ] 4. Extraer Paquete de Fix
```bash
tar -xzf ARGO_DRIVE_SYNC_FIX.tar.gz
ls -lh drive_manager_FIXED.py
```
**Debe existir**: Código corregido disponible

---

## DEPLOYMENT (3 minutos)

### [ ] 5. Copiar Código Corregido
```bash
cp drive_manager_FIXED.py core/drive_manager.py
```

### [ ] 6. Verificar Sintaxis Python
```bash
python -m py_compile core/drive_manager.py
```
**Resultado esperado**: Sin errores
**Si hay error**: Restaurar backup y revisar

### [ ] 7. Verificar Import
```bash
python -c "import sys; sys.path.insert(0, '.'); from core.drive_manager import DriveManager; print('✓ Import OK')"
```
**Resultado esperado**: "✓ Import OK"

### [ ] 8. Verificar Método Recursivo
```bash
python -c "
import sys; sys.path.insert(0, '.')
from core.drive_manager import DriveManager
import inspect
source = inspect.getsource(DriveManager._list_files_recursive)
if '_list_files_recursive(' in source and 'self._list_files_recursive' in source:
    print('✓ Recursive method OK')
else:
    print('✗ Recursive method MISSING')
"
```
**Resultado esperado**: "✓ Recursive method OK"

---

## POST-DEPLOYMENT TESTING (10 minutos)

### [ ] 9. Test Rápido de Sintaxis
```bash
# Opcional: ejecutar test suite completo
python scripts/test_drive_sync.py YOUR_FOLDER_ID --project TEST_SYNC
```
**Resultado esperado**: 6/6 tests passed

### [ ] 10. Iniciar ARGO UI
```bash
streamlit run app/ui.py
```
**Verificar**: UI carga sin errores

### [ ] 11. Test de Sincronización Manual

#### Ir a Project Management en UI
- [ ] Abrir proyecto existente con Drive configurado
- [ ] Verificar folder ID está presente
- [ ] Click "Force Synchronization"

#### Observar Consola (Terminal)
Debe mostrar logs como:
```
INFO - Starting RECURSIVE sync of Drive folder...
DEBUG - Recursing into subfolder: PMI/
DEBUG - Recursing into subfolder: PMI/Standards/
DEBUG - Found file: PMI/Standards/ISO.pdf
INFO - Found 25 files (including subfolders)
INFO - Downloading: PMI/PMBOK7.pdf
INFO - Sync completed: 25 downloaded...
```

**Red Flags (problemas)**:
- ❌ No aparece "Recursing into subfolder"
- ❌ "Found X files" es igual que antes
- ❌ Errores de import o sintaxis

### [ ] 12. Verificar Estructura Local

```bash
# Ver estructura de carpetas descargadas
cd data/projects/YOUR_PROJECT_ID/documents/
ls -R

# O con tree si está instalado
tree .
```

**Resultado esperado**: 
- ✅ Subdirectorios presentes
- ✅ Archivos en subcarpetas descargados
- ✅ Estructura refleja Drive

**Ejemplo correcto**:
```
documents/
├── Document1.pdf
├── PMI/
│   ├── PMBOK7.pdf
│   └── Standards/
│       └── ISO.pdf
└── AACE/
    └── TCM.pdf
```

### [ ] 13. Verificar Base de Datos

```bash
python -c "
import sys; sys.path.insert(0, '.')
from core.unified_database import UnifiedDatabase
db = UnifiedDatabase('data/argo.db')
files = db.get_files_by_project('YOUR_PROJECT_ID')
print(f'Total files in DB: {len(files)}')
subfolder_files = [f for f in files if '/' in f['file_path']]
print(f'Files in subfolders: {len(subfolder_files)}')
if subfolder_files:
    print('Sample paths:')
    for f in subfolder_files[:3]:
        print(f\"  - {f['file_path']}\")
"
```

**Resultado esperado**:
- Total files > antes del fix
- Files in subfolders > 0
- Sample paths muestran estructura con "/"

### [ ] 14. Test de Re-Sincronización (Hash Detection)

En ARGO UI:
- [ ] Click "Force Synchronization" nuevamente
- [ ] Observar consola

**Resultado esperado**:
```
INFO - Starting RECURSIVE sync...
DEBUG - Skipping unchanged file: PMI/PMBOK7.pdf (hash match)
DEBUG - Skipping unchanged file: AACE/TCM.pdf (hash match)
INFO - Sync completed: 0 downloaded, 25 skipped
```

**Verificar**:
- ✅ Sync mucho más rápido (segundos vs minutos)
- ✅ Logs muestran "Skipping unchanged file"
- ✅ Mayoría de archivos skipped

---

## FUNCTIONAL TESTING (5 minutos)

### [ ] 15. Test de RAG Search

En ARGO UI (chat):
1. Hacer pregunta sobre contenido que estaba en subcarpeta
   
   **Ejemplo**: "What does PMBOK 7 say about stakeholder management?"
   (donde PMBOK7.pdf está en PMI/ subfolder)

2. Verificar respuesta incluye información del archivo

**Resultado esperado**:
- ✅ RAG encuentra chunks del archivo en subcarpeta
- ✅ Respuesta incluye información relevante
- ✅ Metadata muestra source path correcto

### [ ] 16. Verificar Analytics Dashboard

Si ARGO tiene analytics:
- [ ] Ir a Project Analytics
- [ ] Verificar "Documents Indexed" aumentó
- [ ] Verificar "Total Chunks" aumentó significativamente

**Ejemplo**:
```
Antes:   20 documents, 150 chunks
Después: 45 documents, 380 chunks
```

---

## PERFORMANCE TESTING (5 minutos)

### [ ] 17. Medir Tiempos

**Primera Sincronización (con force=True)**:
```bash
time python -c "
import sys; sys.path.insert(0, '.')
from core.drive_manager import DriveManager
from core.unified_database import UnifiedDatabase
db = UnifiedDatabase('data/argo.db')
dm = DriveManager('config/google_credentials.json', db)
dm.sync_folder('FOLDER_ID', 'TEST_PROJECT', force=True)
"
```

**Resultado esperado**:
- Folders pequeños (10-50 files): 10-30 segundos
- Folders medianos (50-200 files): 30-90 segundos
- Folders grandes (200+ files): 2-5 minutos

**Segunda Sincronización (sin cambios)**:
```bash
time python -c "..." # mismo comando sin force=True
```

**Resultado esperado**:
- Cualquier tamaño: <10 segundos (solo hash checks)

---

## ROLLBACK PLAN (Si algo sale mal)

### [ ] 18. Plan de Rollback

Si hay problemas:

```bash
# 1. Detener ARGO
# Ctrl+C en terminal

# 2. Restaurar backup
cp core/drive_manager_BACKUP_YYYYMMDD_HHMMSS.py core/drive_manager.py

# 3. Verificar
python -m py_compile core/drive_manager.py

# 4. Reiniciar
streamlit run app/ui.py
```

---

## FINAL VERIFICATION (2 minutos)

### [ ] 19. Verificación Final

**Checklist Rápida**:
- [ ] UI carga sin errores
- [ ] Sincronización descarga archivos de subcarpetas
- [ ] Estructura local refleja Drive
- [ ] Base de datos tiene registros con paths completos
- [ ] Re-sync es rápida (hash detection funciona)
- [ ] RAG encuentra contenido de subcarpetas
- [ ] Logs muestran "Recursing into subfolder"

### [ ] 20. Documentar Deployment

Crear nota en proyecto:
```
DEPLOYMENT: ARGO Drive Sync Fix
Date: YYYY-MM-DD
Status: SUCCESS / FAILED
Files synced before: X
Files synced after: Y
Issues encountered: None / [list issues]
Rollback performed: Yes / No
```

---

## SUCCESS CRITERIA

✅ **Deployment exitoso si**:
1. UI funciona sin errores
2. Sincronización descarga >50% más archivos que antes
3. Subdirectorios aparecen en estructura local
4. Base de datos tiene paths con "/"
5. Re-sync skipea archivos sin cambios
6. RAG encuentra contenido de subcarpetas

❌ **Deployment fallido si**:
1. Errores de import o sintaxis
2. UI no carga
3. Sincronización no descarga más archivos
4. No aparecen subdirectorios
5. Errores en logs

---

## TIMING GUIDE

- **Pre-Deployment**: 5 minutos
- **Deployment**: 3 minutos
- **Post-Deployment Testing**: 10 minutos
- **Functional Testing**: 5 minutos
- **Performance Testing**: 5 minutos

**Total estimado**: 30 minutos para deployment completo y verificación

---

## NOTAS ADICIONALES

### Primer Deployment en Producción
- Realizar fuera de horas pico
- Tener backup de base de datos
- Monitorear logs en tiempo real
- Tener plan de rollback listo

### Folders muy Grandes (1000+ archivos)
- Primera sync puede tomar 10-15 minutos
- Considerar hacerlo de noche
- Verificar espacio en disco suficiente

### Si encuentras problemas
1. No entrar en pánico
2. Revisar logs en detalle
3. Consultar SYNC_FAILURE_ANALYSIS.md
4. Rollback si es necesario
5. Re-intentar después de revisar

---

**Preparado por**: Claude (Anthropic)  
**Versión**: 1.0  
**Última actualización**: 2024-11-21

¡Éxito en tu deployment! 🚀

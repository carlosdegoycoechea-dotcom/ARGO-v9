# CÓDIGO COMPARATIVO: OLD vs FIXED

## 🔴 PROBLEMA: drive_manager.py ORIGINAL (v9.0 r25)

### Método sync_folder() - Líneas 73-88

```python
def sync_folder(self, folder_id: str, project_id: str, 
                local_path: Optional[str] = None) -> List[Dict]:
    
    # Initialize Drive service
    credentials = service_account.Credentials.from_service_account_file(...)
    service = build('drive', 'v3', credentials=credentials)
    
    # ❌ PROBLEMA 1: Query NO recursiva
    query = f"'{folder_id}' in parents and trashed=false"
    results = service.files().list(
        q=query,
        fields="files(id, name, mimeType, modifiedTime, size)",
        pageSize=100  # ❌ PROBLEMA 2: Límite bajo sin paginación
    ).execute()
    
    files = results.get('files', [])
    synced_files = []
    
    # Download each file
    for drive_file in files:
        # ❌ PROBLEMA 3: SKIP folders sin recursión
        if drive_file['mimeType'] == 'application/vnd.google-apps.folder':
            continue  # ← AQUÍ ESTÁ EL BUG PRINCIPAL
        
        file_id = drive_file['id']
        filename = drive_file['name']
        
        # Determine local path (no subfolder structure)
        if local_path:
            target_dir = Path(local_path)
        else:
            target_dir = Path(f"data/projects/{project_id}/documents")
        
        target_dir.mkdir(parents=True, exist_ok=True)
        target_file = target_dir / filename  # ❌ PROBLEMA 4: Path plano
        
        # Download file...
        # (código de descarga omitido para brevedad)
```

### Problemas Identificados:
1. ❌ Query solo retorna items del primer nivel
2. ❌ Límite de 100 items sin paginación
3. ❌ Folders son skippeados con `continue`
4. ❌ Paths no preservan estructura de subcarpetas
5. ❌ No hay detección de cambios (sin hash check)

---

## ✅ SOLUCIÓN: drive_manager_FIXED.py

### Nuevo Método _list_files_recursive() - RECURSIVO

```python
def _list_files_recursive(self, folder_id: str, path: str = "") -> List[Dict]:
    """
    List ALL files in folder and subfolders RECURSIVELY
    
    Args:
        folder_id: Drive folder ID
        path: Current relative path (for tracking structure)
    
    Returns:
        List of file metadata dicts with 'drive_path' field
    """
    all_files = []
    
    try:
        # Query for ALL items in this folder
        query = f"'{folder_id}' in parents and trashed=false"
        
        # ✅ FIX 1: Paginación completa
        page_token = None
        while True:
            results = self.service.files().list(
                q=query,
                fields="nextPageToken, files(id, name, mimeType, modifiedTime, md5Checksum, size)",
                pageSize=1000,  # ✅ Límite más alto
                pageToken=page_token
            ).execute()
            
            items = results.get('files', [])
            
            for item in items:
                # ✅ FIX 2: Build full relative path
                item_path = f"{path}/{item['name']}" if path else item['name']
                
                if item['mimeType'] == 'application/vnd.google-apps.folder':
                    # ✅ FIX 3: RECURSE into subfolder (¡CRÍTICO!)
                    logger.debug(f"Recursing into subfolder: {item_path}")
                    
                    subfolder_files = self._list_files_recursive(
                        folder_id=item['id'],
                        path=item_path
                    )
                    all_files.extend(subfolder_files)
                    
                else:
                    # ✅ FIX 4: Regular file - add with FULL path
                    item['drive_path'] = item_path
                    all_files.append(item)
                    logger.debug(f"Found file: {item_path}")
            
            # ✅ FIX 5: Handle pagination
            page_token = results.get('nextPageToken')
            if not page_token:
                break
        
        return all_files
        
    except Exception as e:
        logger.error(f"Error listing Drive folder {folder_id}: {e}")
        return []
```

### Método sync_folder() Actualizado

```python
def sync_folder(self, folder_id: str, project_id: str,
                local_path: Optional[str] = None,
                force: bool = False) -> List[Dict]:
    """
    Sync a Google Drive folder RECURSIVELY to local project
    """
    # Determine base local path
    if local_path:
        base_local_path = Path(local_path)
    else:
        base_local_path = Path(f"data/projects/{project_id}/documents")
    
    base_local_path.mkdir(parents=True, exist_ok=True)
    
    # ✅ FIX: List ALL files recursively
    all_files = self._list_files_recursive(
        folder_id=folder_id,
        path=""  # Start with empty path
    )
    
    logger.info(f"Found {len(all_files)} files (including subfolders)")
    
    synced_files = []
    
    # Download each file preserving folder structure
    for drive_file in all_files:
        try:
            result = self._sync_single_file(
                drive_file=drive_file,
                base_local_path=base_local_path,
                project_id=project_id,
                force=force
            )
            
            if result['action'] in ['downloaded', 'updated']:
                synced_files.append(result)
                
        except Exception as e:
            logger.error(f"Error syncing {drive_file['name']}: {e}")
    
    return synced_files
```

### Nuevo Método _sync_single_file() con Hash Detection

```python
def _sync_single_file(self, drive_file: Dict, base_local_path: Path,
                      project_id: str, force: bool = False) -> Dict:
    """
    Sync a single file from Drive to local storage
    """
    file_id = drive_file['id']
    filename = drive_file['name']
    drive_path = drive_file['drive_path']  # ✅ Full path with folders
    drive_hash = drive_file.get('md5Checksum', '')
    
    # ✅ FIX: Construct local path preserving folder structure
    local_file_path = base_local_path / drive_path
    local_file_path.parent.mkdir(parents=True, exist_ok=True)
    
    # ✅ FIX: Check if file exists and hasn't changed
    if local_file_path.exists() and not force:
        local_hash = self._compute_file_hash(str(local_file_path))
        
        if local_hash == drive_hash:
            logger.debug(f"Skipping unchanged file: {drive_path}")
            return {
                'action': 'skipped',
                'name': filename,
                'path': str(local_file_path),
                'drive_path': drive_path
            }
    
    # Download file
    logger.info(f"Downloading: {drive_path}")
    
    # ... (código de descarga)
    
    # ✅ FIX: Register in database with full path
    if self.db:
        self.db.add_file(
            project_id=project_id,
            filename=filename,
            file_path=drive_path,  # ✅ Store relative path
            file_type=file_ext,
            file_hash=drive_hash,
            file_size=file_size,
            status="pending",
            metadata={
                "drive_folder_structure": drive_path,  # ✅ Full path metadata
                "drive_file_id": file_id,
                "synced_at": datetime.now().isoformat()
            }
        )
    
    return {
        'action': 'downloaded',
        'name': filename,
        'path': str(local_file_path),
        'drive_path': drive_path
    }
```

---

## 📊 COMPARACIÓN LADO A LADO

| Característica | OLD (v9.0 r25) | FIXED |
|---------------|----------------|--------|
| **Recursión** | ❌ No | ✅ Sí, ilimitada |
| **Subcarpetas** | ❌ Ignoradas | ✅ Procesadas |
| **Preservación de Paths** | ❌ Paths planos | ✅ Estructura completa |
| **Paginación** | ❌ 100 items max | ✅ Paginación completa |
| **Hash Detection** | ❌ No | ✅ MD5 checksum |
| **Database Metadata** | ⚠️ Básica | ✅ Completa con paths |
| **Performance** | ⚠️ Lenta (re-descarga todo) | ✅ Rápida (skipea sin cambios) |

---

## 🔄 FLUJO DE EJECUCIÓN

### OLD (ROTO)
```
sync_folder(folder_id)
  ↓
Query: "files in folder_id"
  ↓
Returns: [file1, file2, folder_A/, folder_B/]
  ↓
Loop:
  - file1 → Download ✅
  - file2 → Download ✅
  - folder_A/ → CONTINUE (skip) ❌
  - folder_B/ → CONTINUE (skip) ❌
  ↓
Result: 2 files downloaded
```

### FIXED (CORRECTO)
```
sync_folder(folder_id)
  ↓
_list_files_recursive(folder_id, path="")
  ↓
Query: "files in folder_id"
  ↓
Returns: [file1, file2, folder_A/, folder_B/]
  ↓
Loop:
  - file1 → Add to list with path "file1" ✅
  - file2 → Add to list with path "file2" ✅
  - folder_A/ → RECURSE ✅
      ↓
      Query: "files in folder_A"
      Returns: [file3, file4]
      - file3 → Add with path "folder_A/file3" ✅
      - file4 → Add with path "folder_A/file4" ✅
  - folder_B/ → RECURSE ✅
      ↓
      Query: "files in folder_B"
      Returns: [file5, subfolder_C/]
      - file5 → Add with path "folder_B/file5" ✅
      - subfolder_C/ → RECURSE AGAIN ✅
          ↓
          Query: "files in subfolder_C"
          Returns: [file6]
          - file6 → Add with path "folder_B/subfolder_C/file6" ✅
  ↓
Result: [file1, file2, folder_A/file3, folder_A/file4, 
         folder_B/file5, folder_B/subfolder_C/file6]
  ↓
Download ALL 6 files preserving structure
```

---

## 🎯 IMPACTO EN CHUNKS

### OLD: Chunks Limitados
```python
# Solo archivos del primer nivel se indexan
files_indexed = ["file1.pdf", "file2.xlsx"]

chunks_created = [
    {"content": "...", "metadata": {"source": "file1.pdf"}},
    {"content": "...", "metadata": {"source": "file2.xlsx"}}
]

# Total: ~20 chunks
# Archivos perdidos: folder_A/file3.pdf, folder_A/file4.pdf, etc.
```

### FIXED: Chunks Completos
```python
# TODOS los archivos se indexan con paths completos
files_indexed = [
    "file1.pdf", 
    "file2.xlsx",
    "folder_A/file3.pdf",
    "folder_A/file4.pdf",
    "folder_B/file5.docx",
    "folder_B/subfolder_C/file6.pdf"
]

chunks_created = [
    {"content": "...", "metadata": {"source": "file1.pdf"}},
    {"content": "...", "metadata": {"source": "file2.xlsx"}},
    {"content": "...", "metadata": {"source": "folder_A/file3.pdf", "category": "folder_A"}},
    {"content": "...", "metadata": {"source": "folder_A/file4.pdf", "category": "folder_A"}},
    {"content": "...", "metadata": {"source": "folder_B/file5.docx", "category": "folder_B"}},
    {"content": "...", "metadata": {"source": "folder_B/subfolder_C/file6.pdf", "category": "folder_B"}}
]

# Total: ~70 chunks (250% más contenido searchable!)
```

---

## 💾 BASE DE DATOS

### OLD: Registros Incompletos
```sql
-- Tabla: files
id | filename   | file_path  | status  | metadata
---|------------|------------|---------|----------
1  | file1.pdf  | file1.pdf  | indexed | {}
2  | file2.xlsx | file2.xlsx | indexed | {}

-- 2 registros, sin información de carpetas
```

### FIXED: Registros Completos
```sql
-- Tabla: files
id | filename  | file_path                     | status  | metadata
---|-----------|-------------------------------|---------|----------
1  | file1.pdf | file1.pdf                     | indexed | {...}
2  | file2.xlsx| file2.xlsx                    | indexed | {...}
3  | file3.pdf | folder_A/file3.pdf            | indexed | {"drive_folder_structure": "folder_A/file3.pdf", ...}
4  | file4.pdf | folder_A/file4.pdf            | indexed | {"drive_folder_structure": "folder_A/file4.pdf", ...}
5  | file5.docx| folder_B/file5.docx           | indexed | {"drive_folder_structure": "folder_B/file5.docx", ...}
6  | file6.pdf | folder_B/subfolder_C/file6.pdf| indexed | {"drive_folder_structure": "folder_B/subfolder_C/file6.pdf", ...}

-- 6 registros con paths completos y metadata
```

---

## 🚀 DEPLOYMENT RÁPIDO

```bash
# 1. Backup
cp core/drive_manager.py core/drive_manager_OLD.py

# 2. Deploy
cp drive_manager_FIXED.py core/drive_manager.py

# 3. Done!
streamlit run app/ui.py
```

---

**Diferencia Clave**: El código FIXED reemplaza `continue` (skip) por **RECURSIÓN** cuando encuentra folders, permitiendo exploración completa del árbol de directorios de Google Drive.

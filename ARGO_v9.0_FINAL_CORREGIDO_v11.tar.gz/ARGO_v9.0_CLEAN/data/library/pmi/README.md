# PMI Standards

Coloca aquí documentos de: PMI Standards

Estos documentos estarán disponibles desde todos los proyectos.

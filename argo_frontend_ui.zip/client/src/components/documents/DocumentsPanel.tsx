import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { 
  Upload, 
  FileText, 
  FileSpreadsheet, 
  File, 
  Trash2, 
  Search, 
  Filter,
  MoreVertical,
  CheckCircle2,
  Clock
} from "lucide-react";

interface Document {
  id: string;
  name: string;
  type: string;
  size: string;
  uploadDate: string;
  status: "indexed" | "processing" | "error";
  chunks: number;
}

const MOCK_DOCS: Document[] = [
  { id: "1", name: "Project_Alpha_Specs.pdf", type: "pdf", size: "2.4 MB", uploadDate: "2024-03-10", status: "indexed", chunks: 142 },
  { id: "2", name: "Budget_Q3_2024.xlsx", type: "xlsx", size: "850 KB", uploadDate: "2024-03-11", status: "indexed", chunks: 45 },
  { id: "3", name: "Meeting_Notes_Kickoff.docx", type: "docx", size: "120 KB", uploadDate: "2024-03-12", status: "indexed", chunks: 12 },
  { id: "4", name: "Architecture_Diagram_v2.png", type: "image", size: "4.1 MB", uploadDate: "2024-03-12", status: "processing", chunks: 0 },
];

export function DocumentsPanel() {
  return (
    <div className="p-6 h-full flex flex-col space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-lg font-semibold tracking-tight">Project Documents</h2>
          <p className="text-xs text-muted-foreground">Manage and index knowledge base files</p>
        </div>
        <Button className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-sm">
          <Upload className="w-4 h-4 mr-2" />
          Upload Files
        </Button>
      </div>

      {/* Upload Area */}
      <Card className="border-dashed border-2 border-border bg-secondary/20 hover:bg-secondary/40 transition-colors cursor-pointer">
        <CardContent className="flex flex-col items-center justify-center py-10 text-center space-y-2">
          <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center mb-2">
            <Upload className="w-6 h-6 text-muted-foreground" />
          </div>
          <h3 className="text-sm font-medium">Drag and drop files here</h3>
          <p className="text-xs text-muted-foreground max-w-xs">
            Support for PDF, DOCX, XLSX, TXT, MD, CSV (Max 50MB)
          </p>
        </CardContent>
      </Card>

      {/* Filters and Search */}
      <div className="flex gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search documents..." 
            className="pl-9 bg-card border-border focus-visible:ring-primary"
          />
        </div>
        <Button variant="outline" size="icon" className="border-border bg-card">
          <Filter className="h-4 w-4 text-muted-foreground" />
        </Button>
      </div>

      {/* Documents List */}
      <ScrollArea className="flex-1 -mx-6 px-6">
        <div className="space-y-3 pb-6">
          {MOCK_DOCS.map((doc) => (
            <div 
              key={doc.id} 
              className="group flex items-center justify-between p-4 rounded-lg border border-border bg-card hover:border-primary/50 transition-all"
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded bg-secondary flex items-center justify-center text-muted-foreground">
                  {doc.type === 'pdf' && <FileText className="w-5 h-5" />}
                  {doc.type === 'xlsx' && <FileSpreadsheet className="w-5 h-5" />}
                  {doc.type === 'docx' && <FileText className="w-5 h-5" />}
                  {doc.type === 'image' && <File className="w-5 h-5" />}
                </div>
                <div>
                  <h4 className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">
                    {doc.name}
                  </h4>
                  <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                    <span>{doc.size}</span>
                    <span>•</span>
                    <span>{doc.uploadDate}</span>
                    <span>•</span>
                    <span>{doc.chunks} chunks</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-4">
                {doc.status === 'indexed' ? (
                  <Badge variant="outline" className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20 gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Indexed
                  </Badge>
                ) : (
                  <Badge variant="outline" className="bg-amber-500/10 text-amber-500 border-amber-500/20 gap-1">
                    <Clock className="w-3 h-3 animate-pulse" /> Processing
                  </Badge>
                )}
                
                <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 text-muted-foreground hover:text-destructive">
                  <Trash2 className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}

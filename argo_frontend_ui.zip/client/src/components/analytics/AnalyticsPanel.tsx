import React from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";

const DAILY_DATA = [
  { day: "Mon", tokens: 12500, cost: 2.5 },
  { day: "Tue", tokens: 18900, cost: 3.8 },
  { day: "Wed", tokens: 15600, cost: 3.1 },
  { day: "Thu", tokens: 22400, cost: 4.5 },
  { day: "Fri", tokens: 28900, cost: 5.8 },
  { day: "Sat", tokens: 8400, cost: 1.7 },
  { day: "Sun", tokens: 6200, cost: 1.2 },
];

const PROJECT_DATA = [
  { name: "Alpha", value: 450, color: "hsl(229 76% 66%)" },
  { name: "Beta", value: 300, color: "hsl(262 83% 58%)" },
  { name: "Gamma", value: 200, color: "hsl(145 46% 50%)" },
  { name: "Other", value: 100, color: "hsl(27 83% 57%)" },
];

export function AnalyticsPanel() {
  return (
    <div className="p-6 space-y-6 h-full overflow-y-auto">
      <div>
        <h2 className="text-xl font-semibold tracking-tight">API Usage & Cost Analytics</h2>
        <p className="text-sm text-muted-foreground">Real-time tracking of system resources</p>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Monthly Cost</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$145.20</div>
            <p className="text-xs text-muted-foreground">of $200.00 budget</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Tokens</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2.4M</div>
            <p className="text-xs text-muted-foreground">843 requests</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Daily Average</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$4.84</div>
            <p className="text-xs text-muted-foreground">~80k tokens</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Budget Remaining</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-500">27.4%</div>
            <p className="text-xs text-muted-foreground">$54.80 left</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <Tabs defaultValue="daily" className="space-y-4">
        <TabsList className="bg-muted border border-border">
          <TabsTrigger value="daily" className="data-[state=active]:bg-background">Daily Usage</TabsTrigger>
          <TabsTrigger value="project" className="data-[state=active]:bg-background">By Project</TabsTrigger>
          <TabsTrigger value="model" className="data-[state=active]:bg-background">By Model</TabsTrigger>
          <TabsTrigger value="type" className="data-[state=active]:bg-background">By Type</TabsTrigger>
        </TabsList>

        <TabsContent value="daily" className="space-y-4">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-base">Daily Usage Trend (Last 7 Days)</CardTitle>
            </CardHeader>
            <CardContent className="pl-0">
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={DAILY_DATA}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(0 0% 24%)" vertical={false} />
                    <XAxis 
                      dataKey="day" 
                      stroke="hsl(0 0% 60%)" 
                      fontSize={12} 
                      tickLine={false} 
                      axisLine={false} 
                    />
                    <YAxis 
                      stroke="hsl(0 0% 60%)" 
                      fontSize={12} 
                      tickLine={false} 
                      axisLine={false} 
                      tickFormatter={(value) => `${value/1000}k`}
                    />
                    <Tooltip 
                      cursor={{ fill: 'hsl(0 0% 18%)' }}
                      contentStyle={{ backgroundColor: 'hsl(0 0% 14%)', borderColor: 'hsl(0 0% 24%)', color: 'hsl(0 0% 88%)' }}
                    />
                    <Bar dataKey="tokens" fill="hsl(229 76% 66%)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="project" className="space-y-4">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-base">Cost Distribution by Project</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={PROJECT_DATA}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {PROJECT_DATA.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                      ))}
                    </Pie>
                    <Tooltip 
                       contentStyle={{ backgroundColor: 'hsl(0 0% 14%)', borderColor: 'hsl(0 0% 24%)', color: 'hsl(0 0% 88%)' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

# ✅ TESTING CHECKLIST - ARGO v9.0 COMPLETE FIXED

**Fecha**: 2025-11-21
**Versión**: v9.0 COMPLETE FIXED

---

## 🎯 OBJETIVO

Verificar que TODOS los cambios funcionan correctamente antes de continuar con el frontend.

---

## 📋 PRE-REQUISITOS

- [ ] Python 3.10+ instalado
- [ ] Archivo `.env` con `OPENAI_API_KEY`
- [ ] Google credentials configurado (si vas a testear Drive)
- [ ] Tesseract OCR instalado (para test de imágenes)

---

## ✅ TEST 1: INSTALACIÓN LIMPIA

### Objetivo
Verificar que el sistema se instala sin errores.

### Pasos

```bash
# 1. Extraer paquete
cd /ruta/temporal
tar -xzf ARGO_v9.0_COMPLETE_FIXED.tar.gz
cd ARGO_v9.0_CLEAN

# 2. Crear ambiente virtual
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# 3. Instalar dependencias
pip install -r requirements.txt
```

### Criterio de Éxito
- [ ] Extracción exitosa
- [ ] Ambiente virtual creado
- [ ] Todas las dependencias instaladas sin errores
- [ ] Sin mensajes de conflicto de versiones

### Si Falla
- Verificar versión de Python (debe ser 3.10+)
- Verificar pip actualizado: `pip install --upgrade pip`

---

## ✅ TEST 2: COMPILACIÓN DE MÓDULOS

### Objetivo
Verificar que todos los archivos Python compilan sin errores.

### Pasos

```bash
cd ARGO_v9.0_CLEAN

# Test individual de cada módulo crítico
python -m py_compile core/drive_manager.py
python -m py_compile tools/extractors.py
python -m py_compile core/rag_engine.py
python -m py_compile core/bootstrap.py

# Test de todos los módulos core
python -m py_compile core/*.py

# Test de imports
python -c "from core.drive_manager import DriveManager; print('✓ DriveManager OK')"
python -c "from tools.extractors import extract_and_chunk; print('✓ Extractors OK')"
python -c "from core.rag_engine import UnifiedRAGEngine; print('✓ RAG Engine OK')"
python -c "from core.bootstrap import initialize_argo; print('✓ Bootstrap OK')"
```

### Criterio de Éxito
- [ ] Todos los `py_compile` sin errores
- [ ] Todos los imports exitosos
- [ ] Sin `SyntaxError` o `ImportError`

### Si Falla
- Revisar que instalaste TODAS las dependencias
- Verificar que no hay archivos `.pyc` corruptos
- Verificar que copiaste los archivos correctamente

---

## ✅ TEST 3: LANGCHAIN WARNING FIX

### Objetivo
Verificar que NO hay deprecation warnings de langchain.

### Pasos

```bash
cd ARGO_v9.0_CLEAN

# Crear .env mínimo (si no existe)
echo "OPENAI_API_KEY=sk-test" > .env

# Iniciar Streamlit y capturar warnings
streamlit run app/ui.py 2>&1 | grep -i "deprecation\|langchain.schema" &
STREAMLIT_PID=$!

# Esperar 10 segundos
sleep 10

# Matar Streamlit
kill $STREAMLIT_PID
```

### Criterio de Éxito
- [ ] NO aparece mensaje: `DeprecationWarning: langchain.schema is deprecated`
- [ ] NO aparece: `Use langchain_core.messages instead`
- [ ] Streamlit inicia sin warnings de langchain

### Si Falla
- Verificar que instalaste `langchain-core==0.1.23`
- Verificar que el archivo `core/rag_engine.py` tiene la línea correcta:
  ```python
  from langchain_core.messages import HumanMessage  # ✓ Correcto
  ```

---

## ✅ TEST 4: DRIVE SYNC RECURSIVO

### Objetivo
Verificar que Drive sync ahora sincroniza TODAS las subcarpetas.

### Pre-requisitos
- [ ] Google credentials configurado en `config/google_credentials.json`
- [ ] Carpeta de Drive con subcarpetas (al menos 2 niveles)

### Pasos

```bash
# 1. Iniciar ARGO
streamlit run app/ui.py

# 2. En la UI:
# - Ir a "Project Management"
# - Crear o seleccionar un proyecto
# - Configurar Drive folder ID
# - Click "Force Synchronization"

# 3. Observar consola (terminal donde corre Streamlit)
# Debes ver mensajes como:
# "Recursing into subfolder: PMI/"
# "Downloading: PMI/PMBOK7.pdf"
# "Found X files (including subfolders)"

# 4. Verificar estructura local
ls -R data/projects/TU_PROYECTO/documents/
```

### Criterio de Éxito
- [ ] Logs muestran "Recursing into subfolder: ..."
- [ ] Se crearon subdirectorios en `data/projects/.../documents/`
- [ ] Archivos en subcarpetas fueron descargados
- [ ] Cantidad de archivos sincronizados > antes del fix

### Comparación Antes/Después

**Antes**:
```
Found 2 files
Downloading: Doc1.pdf
Downloading: Doc2.xlsx
Successfully synced 2 files
```

**Después**:
```
Found 8 files (including subfolders)
Recursing into subfolder: PMI/
Downloading: Doc1.pdf
Downloading: Doc2.xlsx
Downloading: PMI/PMBOK7.pdf
Downloading: PMI/Standards/ISO21500.pdf
Successfully synced 8 files
```

### Si Falla
- Verificar que reemplazaste el archivo `core/drive_manager.py`
- Verificar permisos del service account en Google Drive
- Verificar que el folder ID es correcto

---

## ✅ TEST 5: HASH-BASED CHANGE DETECTION

### Objetivo
Verificar que syncs subsiguientes son rápidas (solo hash checks).

### Pasos

```bash
# 1. Hacer primera sync (ya hiciste en Test 4)
# Primera sync: ~2-3 minutos para 10 archivos

# 2. Sin cambiar NADA en Drive, hacer segunda sync
# Click "Force Synchronization" de nuevo

# 3. Observar consola
# Debes ver:
# "Skipping unchanged file: Doc1.pdf"
# "Skipping unchanged file: PMI/PMBOK7.pdf"
# "Successfully synced 0 files, 8 skipped (unchanged)"
```

### Criterio de Éxito
- [ ] Segunda sync termina en <10 segundos
- [ ] Logs muestran "Skipping unchanged file: ..."
- [ ] No se descargan archivos sin cambios

### Si Falla
- El fix de hash detection está funcionando si ves los mensajes "Skipping"
- Si vuelve a descargar todo, verifica que `drive_manager.py` tiene la función `_compute_file_hash()`

---

## ✅ TEST 6: NUEVOS FORMATOS - POWERPOINT

### Objetivo
Verificar soporte para archivos PPT/PPTX.

### Pre-requisitos
- [ ] `python-pptx` instalado

### Pasos

```bash
cd ARGO_v9.0_CLEAN

# Test en Python
python << EOF
from tools.extractors import extract_and_chunk

# Crear PowerPoint de prueba
from pptx import Presentation
prs = Presentation()
slide = prs.slides.add_slide(prs.slide_layouts[0])
slide.shapes.title.text = "Test Slide"
prs.save("test.pptx")

# Extraer
chunks = extract_and_chunk("test.pptx", "pptx")
print(f"✓ PPT: {len(chunks)} chunks extracted")
print(f"Content: {chunks[0]['content'][:100]}...")

import os
os.remove("test.pptx")
EOF
```

### Criterio de Éxito
- [ ] Script termina sin errores
- [ ] Muestra "✓ PPT: X chunks extracted"
- [ ] Content contiene texto de las slides

### Si Falla
- Instalar: `pip install python-pptx`
- Verificar que `extractors.py` tiene la función `_extract_ppt()`

---

## ✅ TEST 7: NUEVOS FORMATOS - IMÁGENES CON OCR

### Objetivo
Verificar soporte para OCR en imágenes.

### Pre-requisitos
- [ ] `Pillow` y `pytesseract` instalados
- [ ] Tesseract OCR instalado en sistema

### Pasos

```bash
# 1. Verificar Tesseract
tesseract --version
# Debe mostrar versión instalada

# 2. Test en Python
python << EOF
from tools.extractors import extract_and_chunk
from PIL import Image, ImageDraw, ImageFont

# Crear imagen de prueba con texto
img = Image.new('RGB', (400, 100), color='white')
d = ImageDraw.Draw(img)
d.text((10,10), "ARGO Test Image", fill='black')
img.save("test.png")

# Extraer con OCR
chunks = extract_and_chunk("test.png", "png")
print(f"✓ Image: {len(chunks)} chunks extracted")
print(f"Content: {chunks[0]['content']}")

import os
os.remove("test.png")
EOF
```

### Criterio de Éxito
- [ ] Script termina sin errores
- [ ] Detecta texto en la imagen
- [ ] Muestra "ARGO Test Image" en content

### Si Falla
- Instalar Tesseract:
  ```bash
  # Ubuntu/Debian
  sudo apt-get install tesseract-ocr

  # macOS
  brew install tesseract

  # Windows
  # Descargar de: https://github.com/UB-Mannheim/tesseract/wiki
  ```
- Instalar Python packages: `pip install Pillow pytesseract`

---

## ✅ TEST 8: NUEVOS FORMATOS - XER (PRIMAVERA)

### Objetivo
Verificar soporte para archivos XER de Primavera P6.

### Pasos

```bash
python << EOF
from tools.extractors import extract_and_chunk

# Crear XER de prueba
xer_content = """ERMHDR
%T	PROJECT
%F	proj_id	proj_short_name
%R	1	PALLAS
%T	TASK
%F	task_id	task_name	wbs_id
%R	1	Engineering	1
%R	2	Procurement	1
"""

with open("test.xer", "w") as f:
    f.write(xer_content)

# Extraer
chunks = extract_and_chunk("test.xer", "xer")
print(f"✓ XER: {len(chunks)} chunks extracted")
print(f"Content: {chunks[0]['content'][:200]}...")

import os
os.remove("test.xer")
EOF
```

### Criterio de Éxito
- [ ] Script termina sin errores
- [ ] Muestra "✓ XER: X chunks extracted"
- [ ] Content contiene info del proyecto

### Si Falla
- Verificar que `extractors.py` tiene la función `_extract_xer()`
- Este formato no requiere librerías externas

---

## ✅ TEST 9: INICIO DE UI SIN ERRORES

### Objetivo
Verificar que la UI inicia completamente sin errores.

### Pasos

```bash
cd ARGO_v9.0_CLEAN

# Configurar .env mínimo
cat > .env << EOF
OPENAI_API_KEY=tu_api_key_aqui
EOF

# Iniciar Streamlit
streamlit run app/ui.py
```

### Criterio de Éxito
- [ ] Streamlit inicia sin errores
- [ ] No aparece traceback en consola
- [ ] UI se abre en navegador
- [ ] Puede navegar por la interfaz
- [ ] Puede crear/seleccionar proyecto

### Si Falla
- Revisar logs en consola
- Verificar que `.env` tiene `OPENAI_API_KEY`
- Verificar que database se creó: `ls data/argo_unified.db`

---

## ✅ TEST 10: CHAT BÁSICO (END-TO-END)

### Objetivo
Verificar funcionalidad básica end-to-end.

### Pasos

```bash
# 1. Con UI abierta (del Test 9)

# 2. En la interfaz:
# - Crear proyecto "TEST_PROJECT"
# - Subir un archivo PDF
# - Hacer una pregunta sobre el archivo
# - Verificar que responde

# 3. Observar consola
# - Verificar que no hay warnings
# - Verificar que se procesa el archivo
# - Verificar que RAG busca en vectorstore
```

### Criterio de Éxito
- [ ] Archivo se sube exitosamente
- [ ] Sistema lo procesa y crea chunks
- [ ] Chat responde usando el contenido del archivo
- [ ] Sin warnings en consola

### Si Falla
- Verificar que tienes `OPENAI_API_KEY` válido
- Verificar logs para el error específico

---

## 📊 RESUMEN DE TESTS

| Test # | Nombre | Prioridad | Tiempo | Estado |
|--------|--------|-----------|--------|--------|
| 1 | Instalación Limpia | CRÍTICO | 5 min | [ ] |
| 2 | Compilación de Módulos | CRÍTICO | 2 min | [ ] |
| 3 | Langchain Warning Fix | ALTO | 2 min | [ ] |
| 4 | Drive Sync Recursivo | CRÍTICO | 5 min | [ ] |
| 5 | Hash Change Detection | ALTO | 2 min | [ ] |
| 6 | PowerPoint Support | MEDIO | 3 min | [ ] |
| 7 | Image OCR Support | MEDIO | 5 min | [ ] |
| 8 | XER Support | BAJO | 3 min | [ ] |
| 9 | UI Inicio | CRÍTICO | 2 min | [ ] |
| 10 | Chat End-to-End | CRÍTICO | 5 min | [ ] |

**Total Tiempo Estimado**: ~35 minutos

---

## ✅ CRITERIOS DE APROBACIÓN

Para aprobar esta versión, debes completar exitosamente:

### Mínimo Requerido (CRÍTICO)
- [ ] Test 1: Instalación Limpia
- [ ] Test 2: Compilación de Módulos
- [ ] Test 3: Langchain Warning Fix
- [ ] Test 9: UI Inicio
- [ ] Test 10: Chat End-to-End

### Recomendado (ALTO)
- [ ] Test 4: Drive Sync Recursivo
- [ ] Test 5: Hash Change Detection

### Opcional (MEDIO/BAJO)
- [ ] Test 6-8: Nuevos Formatos

---

## 🚨 SI ALGO FALLA

### Paso 1: Identificar el Test
Anota cuál test falló y el mensaje de error exacto.

### Paso 2: Revisar Logs
```bash
# Capturar logs completos
streamlit run app/ui.py > argo_logs.txt 2>&1
```

### Paso 3: Verificar Archivos
```bash
# Verificar que tienes los archivos correctos
md5sum core/drive_manager.py
md5sum tools/extractors.py
md5sum core/rag_engine.py
```

### Paso 4: Rollback (si necesario)
Si algo está muy roto, vuelve a la versión anterior:
```bash
# Restaurar backup
cp core/drive_manager_BACKUP.py core/drive_manager.py
# O descargar versión anterior del repo
```

---

## 📝 REPORTE DE RESULTADOS

Después de completar los tests, reporta:

```
ARGO v9.0 COMPLETE FIXED - TEST RESULTS
========================================

Tests Completados: X/10
Tests Exitosos: Y/10
Tests Fallidos: Z/10

Tests CRÍTICOS:
[ ] Test 1: Instalación
[ ] Test 2: Compilación
[ ] Test 3: Langchain Fix
[ ] Test 9: UI Inicio
[ ] Test 10: Chat E2E

Tests ALTOS:
[ ] Test 4: Drive Sync
[ ] Test 5: Hash Detection

Problemas Encontrados:
- [Describir si encontraste alguno]

Recomendación:
[ ] APROBADO - Continuar con frontend
[ ] REVISAR - Arreglar issues primero
[ ] RECHAZADO - Volver a versión anterior
```

---

**Checklist Preparado Por**: Claude (Anthropic)
**Fecha**: 2025-11-21
**Versión**: v9.0 COMPLETE FIXED

✅ **¡Buena suerte con los tests!**

# 🎯 ARGO CORE - TECHNICAL SPECIFICATION FOR CLAUDE CODE
## Complete Core Enhancement & Intelligence Improvement

**Document Version**: 1.0  
**Target System**: ARGO v9.0 r25  
**Priority**: CRITICAL - Core Functionality  
**Audience**: Claude Code (AI Developer)

---

## 📋 EXECUTIVE SUMMARY

### Objective
Strengthen ARGO's CORE system to create a production-ready, intelligent PMO assistant with:
1. ✅ **Robust Core** - Error-free, well-tested foundation
2. ✅ **High Intelligence** - Advanced reasoning and context awareness
3. ✅ **Extensible Architecture** - Plugin-ready for external analyzers
4. ✅ **Production Quality** - Enterprise-grade reliability

### Current State Analysis

**CORE Components Status**:
- Bootstrap: ✅ Functional (minor warning)
- Database: ✅ Functional
- Model Router: ✅ Functional (improved vs v8.5.3)
- RAG Engine: ⚠️ Warning (langchain deprecation)
- System Prompt: ❌ **TOO BASIC** - Major intelligence issue

**Critical Problem Identified**:
The current system prompt is ~17 lines and lacks:
- Advanced reasoning instructions
- PMO-specific expertise
- Context prioritization rules
- Chain-of-thought reasoning
- Confidence calibration
- Source attribution protocols

---

## 🔴 PROBLEM 1: SYSTEM PROMPT IS TOO BASIC

### Current Prompt (Lines 1117-1134)

```python
system_prompt = f"""You are ARGO, an enterprise project management assistant.

IMPORTANT: Today's date is {current_day} ({current_date}).
You have access to current date and time information.

Use the following context to answer the user's question accurately and professionally.

{context}

Guidelines:
- Answer based on the context provided
- Be concise and professional
- Cite sources when appropriate
- If information is not in context, state this clearly
- Use proper business terminology
- Do not use emojis in your responses
- When asked about current date/time, use the date provided above
- For deadline analysis, calculate days remaining using today's date"""
```

### Why This Is Insufficient

**1. No Reasoning Framework**
- No instructions for HOW to think through problems
- No chain-of-thought guidance
- No multi-step reasoning protocol

**2. No PMO Expertise**
- Doesn't leverage PMI/PMBOK knowledge
- No project management methodologies
- No standard terminology enforcement

**3. No Context Prioritization**
- All context chunks treated equally
- No recency weighting
- No source authority hierarchy

**4. No Confidence Calibration**
- Doesn't teach model when to hedge
- No explicit uncertainty handling
- No "I don't know" triggers

**5. No Advanced Capabilities**
- No multi-document synthesis
- No comparative analysis
- No trend identification
- No proactive recommendations

---

## ✅ SOLUTION 1: ADVANCED SYSTEM PROMPT

### New Prompt Architecture

```python
def build_advanced_system_prompt(
    context: str,
    project_metadata: Dict,
    current_date: str,
    conversation_summary: Optional[str] = None
) -> str:
    """
    Build advanced system prompt with PMO expertise
    
    Structure:
    1. Identity & Role
    2. Core Capabilities
    3. Reasoning Framework
    4. PMO Expertise
    5. Context Handling
    6. Response Protocol
    7. Confidence Calibration
    """
    
    # 1. IDENTITY & ROLE
    identity = f"""You are ARGO, an enterprise-grade Project Management Office (PMO) assistant 
specialized in nuclear power plant projects, particularly the PALLAS reactor program.

Current Context:
- Date: {current_date}
- Project: {project_metadata.get('name', 'Unknown')}
- Project Type: {project_metadata.get('project_type', 'standard')}
- Phase: {project_metadata.get('phase', 'execution')}"""

    # 2. CORE CAPABILITIES
    capabilities = """
Core Capabilities:
• Document Analysis: Extract insights from technical documents, schedules, reports
• Schedule Intelligence: Analyze critical paths, float, dependencies, delays
• Risk Assessment: Identify, quantify, and prioritize project risks
• Earned Value Analysis: Track cost/schedule performance vs. baseline
• Stakeholder Communication: Translate technical details for various audiences
• Regulatory Compliance: Apply nuclear industry standards (ASME, NRC, IAEA)
• PMI Standards: PMBOK 7th Edition, Practice Standards, PMI Lexicon
• AACE Standards: TCM Framework, Cost Engineering principles"""

    # 3. REASONING FRAMEWORK
    reasoning = """
Reasoning Protocol:
When answering questions, follow this structured approach:

Step 1: UNDERSTAND THE QUERY
- Identify the core question
- Determine required information type (fact, analysis, recommendation)
- Assess if query is answerable with available context

Step 2: ANALYZE AVAILABLE CONTEXT
- Review all provided document chunks
- Prioritize by relevance score and recency
- Identify gaps in information

Step 3: SYNTHESIZE INFORMATION
- Combine information from multiple sources if needed
- Resolve any contradictions (favor more recent/authoritative sources)
- Build coherent narrative

Step 4: APPLY PMO EXPERTISE
- Use standard PMO terminology (WBS, EVM, DCMA, etc.)
- Apply project management best practices
- Consider nuclear industry context

Step 5: FORMULATE RESPONSE
- Lead with direct answer
- Provide supporting evidence
- Cite specific sources
- Note any limitations or assumptions

Step 6: CALIBRATE CONFIDENCE
- High confidence (>80%): Information directly stated in context
- Medium confidence (50-80%): Information inferred or synthesized
- Low confidence (<50%): Information incomplete or uncertain"""

    # 4. PMO EXPERTISE LAYER
    pmo_expertise = """
Project Management Knowledge:

Schedule Management:
- Critical Path: Sequence of activities with zero float determining project duration
- Float/Slack: Schedule flexibility; Total Float = Late Start - Early Start
- Near-Critical: Activities with float < 5 days, high risk of becoming critical
- Schedule Performance Index (SPI) = EV / PV; <1.0 indicates behind schedule

Cost Management:
- Cost Performance Index (CPI) = EV / AC; <1.0 indicates over budget
- Estimate at Completion (EAC): Projected total cost at project end
- Variance at Completion (VAC) = BAC - EAC
- To-Complete Performance Index (TCPI): Required efficiency to meet budget

Risk Management:
- Qualitative: Probability × Impact matrix (1-5 scale)
- Quantitative: Monte Carlo, sensitivity analysis, expected monetary value
- Risk Register: ID, Description, Owner, Mitigation, Status

Quality Standards:
- DCMA 14-Point Assessment: Schedule quality metrics (DoD standard)
- GAO Schedule Assessment: Government Accountability Office guidelines
- ASME NQA-1: Nuclear Quality Assurance standard
- 10 CFR Part 50: NRC licensing requirements for nuclear plants"""

    # 5. CONTEXT HANDLING
    context_handling = f"""
Available Context:
{context}

Context Usage Rules:
1. PRIORITIZE information by:
   - Relevance score (higher = more relevant to query)
   - Recency (newer documents > older for same topic)
   - Authority (official standards > emails)
   
2. ATTRIBUTE sources explicitly:
   - Direct quotes: "According to [Document X], '...'"
   - Paraphrases: "As stated in [Document Y]..."
   - Synthesis: "Based on [Doc A] and [Doc B]..."

3. HANDLE conflicts:
   - If sources disagree, note the discrepancy
   - Favor official/authoritative sources
   - Indicate if resolution requires human judgment

4. IDENTIFY gaps:
   - If context insufficient, state clearly
   - Suggest what additional information is needed
   - Do NOT fabricate information"""

    # 6. RESPONSE PROTOCOL
    response_protocol = """
Response Format Guidelines:

For FACTUAL questions:
Structure: Direct answer → Evidence → Source citation
Example: "The project completion date is March 15, 2026 (Source: Project Schedule Rev 23)."

For ANALYTICAL questions:
Structure: Summary → Detailed analysis → Implications → Recommendations
Example: "Schedule analysis shows 15% of activities are critical..."

For COMPARISON questions:
Structure: Comparison table/summary → Key differences → Implications
Use tables for structured comparisons when appropriate

For STATUS questions:
Structure: Current state → Variance from plan → Trend → Outlook
Include metrics: "Schedule: 3 days behind. CPI: 0.94 (6% over budget)"

For RECOMMENDATION questions:
Structure: Situation → Options → Analysis → Recommended action → Risks
Always provide rationale for recommendations

Communication Style:
- PROFESSIONAL: Business terminology, no casual language
- CONCISE: Direct answers, avoid unnecessary elaboration  
- PRECISE: Use specific numbers, dates, percentages
- STRUCTURED: Use headings, bullets, tables for clarity
- NO EMOJIS: Corporate environment"""

    # 7. CONFIDENCE & LIMITATIONS
    confidence = """
Confidence Calibration:

HIGH CONFIDENCE (Use definitive language):
- Information explicitly stated in provided documents
- Direct data extraction (dates, numbers, names)
- Calculations based on provided data
Example: "The baseline budget is $450M as stated in the Project Charter."

MEDIUM CONFIDENCE (Use qualified language):
- Information synthesized from multiple sources
- Reasonable inferences from context
- Industry standard practices
Example: "Based on the activity dependencies, this likely represents..."

LOW CONFIDENCE (Explicit hedging):
- Limited information available
- Extrapolation required
- Assumptions necessary
Example: "With the limited information available, it appears that... However, confirmation with [stakeholder] is recommended."

INSUFFICIENT INFORMATION (Clear admission):
"The provided documents do not contain information about [topic]. To answer this question, I would need access to [specific documents/data]."

Never:
- Fabricate information not in context
- Make up document references
- Provide confident answers when uncertain
- Hallucinate data, dates, or metrics"""

    # 8. SPECIAL INSTRUCTIONS
    special = """
Special Instructions:

Date/Time Awareness:
- Today is {current_date}
- Use this for deadline calculations
- Calculate "days remaining" = Target Date - Today
- Flag overdue items explicitly

Conversation Context:
- Remember user's previous questions in this session
- Build on previous answers
- Reference earlier parts of conversation when relevant
{f"Conversation Summary: {conversation_summary}" if conversation_summary else ""}

Output Constraints:
- Maximum response length: 3000 words (be concise)
- Use markdown formatting for structure
- Create tables for comparative data
- Use bullet points for lists
- Bold key terms and metrics

Critical Don'ts:
- NO emojis or casual language
- NO fabricated sources or citations  
- NO overly confident statements without evidence
- NO jargon without explanation for non-technical users
- NO assumptions about confidential information"""

    # ASSEMBLE COMPLETE PROMPT
    complete_prompt = f"""{identity}

{capabilities}

{reasoning}

{pmo_expertise}

{context_handling}

{response_protocol}

{confidence}

{special}

Now, answer the user's question following all the above guidelines."""

    return complete_prompt
```

---

## 🔴 PROBLEM 2: LANGCHAIN DEPRECATION

### Current Issue
```python
# core/rag_engine.py, line 12
from langchain.schema import HumanMessage  # ⚠️ Deprecated
```

### Fix
```python
# Replace with:
from langchain_core.messages import HumanMessage

# Update requirements.txt:
langchain-core==0.1.23
```

---

## 🔴 PROBLEM 3: RAG CONTEXT BUILDING

### Current Implementation (Lines 1103-1125)

```python
# Very basic context building
context_str = ""
for r in results:
    context_str += f"\n---\nSource: {r.metadata.get('source')}\n"
    context_str += f"Content: {r.content}\n"

# Problem: No structure, no prioritization, no metadata
```

### Enhanced Context Builder

```python
def build_enhanced_context(
    results: List[SearchResult],
    max_tokens: int = 8000,
    include_metadata: bool = True
) -> str:
    """
    Build structured, prioritized context from search results
    
    Features:
    - Prioritization by score
    - Metadata preservation
    - Token budget management
    - Source grouping
    - Recency indicators
    """
    
    # Sort by score (descending)
    sorted_results = sorted(results, key=lambda x: x.score, reverse=True)
    
    context_parts = []
    token_count = 0
    
    # Group by source document
    by_source = {}
    for r in sorted_results:
        source = r.metadata.get('source', 'Unknown')
        if source not in by_source:
            by_source[source] = []
        by_source[source].append(r)
    
    context_parts.append("=== AVAILABLE CONTEXT ===\n")
    context_parts.append(f"Retrieved {len(results)} relevant chunks from {len(by_source)} documents.\n")
    context_parts.append("Documents are ordered by relevance to your query.\n\n")
    
    # Build context by document
    for doc_idx, (source, chunks) in enumerate(by_source.items(), 1):
        # Check token budget
        estimated_tokens = len(" ".join([c.content for c in chunks])) / 4
        if token_count + estimated_tokens > max_tokens:
            context_parts.append(f"\n[Additional {len(by_source) - doc_idx + 1} documents omitted due to token limit]")
            break
        
        # Document header
        context_parts.append(f"\n{'='*60}")
        context_parts.append(f"DOCUMENT {doc_idx}: {source}")
        
        # Add metadata if available
        if include_metadata and chunks[0].metadata:
            metadata = chunks[0].metadata
            
            if 'file_type' in metadata:
                context_parts.append(f"Type: {metadata['file_type'].upper()}")
            
            if 'created_at' in metadata:
                context_parts.append(f"Date: {metadata['created_at']}")
            
            if 'category' in metadata:
                context_parts.append(f"Category: {metadata['category']}")
            
            # Relevance score (average of chunks from this doc)
            avg_score = sum(c.score for c in chunks) / len(chunks)
            context_parts.append(f"Relevance: {avg_score:.0%}")
        
        context_parts.append(f"{'='*60}\n")
        
        # Add chunks from this document
        for chunk_idx, chunk in enumerate(chunks, 1):
            context_parts.append(f"\n--- Section {chunk_idx} (Score: {chunk.score:.0%}) ---")
            context_parts.append(chunk.content)
            context_parts.append("")  # Blank line
        
        token_count += estimated_tokens
    
    context_parts.append(f"\n{'='*60}")
    context_parts.append("END OF CONTEXT")
    context_parts.append(f"{'='*60}\n")
    
    return "\n".join(context_parts)
```

---

## 🔴 PROBLEM 4: NO CHAIN-OF-THOUGHT REASONING

### Current Behavior
Model jumps directly to answer without showing reasoning.

### Solution: Implement CoT

```python
def enable_chain_of_thought(
    messages: List[Dict],
    question_type: str = "analytical"
) -> List[Dict]:
    """
    Add chain-of-thought prompting for better reasoning
    
    question_type: "factual", "analytical", "recommendation"
    """
    
    # Detect question type if not provided
    if not question_type:
        question_type = detect_question_type(messages[-1]['content'])
    
    # Add CoT instruction based on type
    if question_type == "analytical":
        cot_instruction = """
Before answering, walk through your analysis step-by-step:

1. What information do I need?
2. What information do I have in the context?
3. What patterns or trends do I see?
4. What are the implications?
5. What's my conclusion?

Then provide your answer."""

    elif question_type == "recommendation":
        cot_instruction = """
Before recommending, reason through:

1. What is the current situation?
2. What are the available options?
3. What are pros/cons of each?
4. What are the risks?
5. What do PMO best practices suggest?
6. What's my recommendation and why?

Then provide your recommendation."""

    elif question_type == "factual":
        cot_instruction = """
Before answering:

1. Where in the context is this information?
2. Is it explicitly stated or must I infer?
3. Are there multiple sources? Do they agree?
4. How confident am I?

Then provide your answer."""
    
    # Insert CoT instruction before user's question
    messages_with_cot = messages[:-1]  # All except last
    messages_with_cot.append({
        "role": "system",
        "content": cot_instruction
    })
    messages_with_cot.append(messages[-1])  # User question
    
    return messages_with_cot
```

---

## 🔴 PROBLEM 5: NO CONVERSATION MEMORY INTEGRATION

### Current State
Conversation history included but not leveraged for intelligence.

### Solution: Conversation-Aware Context

```python
def build_conversation_aware_context(
    current_query: str,
    conversation_history: List[Dict],
    rag_results: List[SearchResult]
) -> Dict:
    """
    Build context that's aware of conversation flow
    
    Returns:
        {
            'primary_context': str,  # From RAG
            'conversation_context': str,  # From history
            'follow_up_indicators': List[str]  # Detected follow-ups
        }
    """
    
    # Detect if current query is a follow-up
    follow_up_indicators = []
    
    follow_up_patterns = [
        r"what about",
        r"how about",
        r"what if",
        r"in that case",
        r"also",
        r"additionally",
        r"furthermore",
        r"regarding that",
        r"about (that|this|it)",
    ]
    
    query_lower = current_query.lower()
    for pattern in follow_up_patterns:
        if re.search(pattern, query_lower):
            follow_up_indicators.append(pattern)
    
    # Extract entities from recent conversation
    recent_entities = extract_entities_from_history(
        conversation_history[-6:]  # Last 3 exchanges
    )
    
    # Build conversation summary
    if len(conversation_history) > 0:
        conversation_context = "Previous conversation context:\n"
        
        # Summarize last few exchanges
        for msg in conversation_history[-4:]:  # Last 2 exchanges
            role = msg['role'].title()
            content_preview = msg['content'][:150]
            conversation_context += f"{role}: {content_preview}...\n"
        
        # Add detected entities
        if recent_entities:
            conversation_context += f"\nEntities discussed: {', '.join(recent_entities)}\n"
        
        # Add follow-up note if detected
        if follow_up_indicators:
            conversation_context += f"\nNote: Current query appears to be a follow-up question referencing previous discussion.\n"
    else:
        conversation_context = ""
    
    return {
        'primary_context': build_enhanced_context(rag_results),
        'conversation_context': conversation_context,
        'follow_up_indicators': follow_up_indicators
    }

def extract_entities_from_history(messages: List[Dict]) -> List[str]:
    """Extract key entities (dates, names, terms) from conversation"""
    entities = set()
    
    for msg in messages:
        content = msg['content']
        
        # Extract dates (YYYY-MM-DD format)
        dates = re.findall(r'\d{4}-\d{2}-\d{2}', content)
        entities.update(dates)
        
        # Extract capitalized terms (likely proper nouns)
        # Avoid common words
        common_words = {'The', 'A', 'An', 'In', 'On', 'At', 'To', 'For', 'Of', 'As', 'By'}
        proper_nouns = re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b', content)
        entities.update([n for n in proper_nouns if n not in common_words])
        
        # Extract quoted terms (likely important)
        quoted = re.findall(r'"([^"]+)"', content)
        entities.update(quoted)
    
    return list(entities)[:10]  # Top 10 most recent
```

---

## 🔴 PROBLEM 6: NO RESPONSE QUALITY SCORING

### Solution: Automated Response Evaluation

```python
class ResponseQualityScorer:
    """
    Evaluate response quality automatically
    """
    
    def score_response(
        self,
        query: str,
        response: str,
        context: str,
        rag_scores: List[float]
    ) -> Dict:
        """
        Score response on multiple dimensions
        
        Returns:
            {
                'overall_score': float,  # 0-1
                'dimensions': {
                    'relevance': float,
                    'completeness': float,
                    'source_attribution': float,
                    'confidence': float,
                    'specificity': float
                },
                'flags': List[str],  # Potential issues
                'confidence_level': str  # 'high', 'medium', 'low'
            }
        """
        
        dimensions = {}
        flags = []
        
        # 1. RELEVANCE: Does response address the query?
        dimensions['relevance'] = self._score_relevance(query, response)
        if dimensions['relevance'] < 0.5:
            flags.append("Response may not fully address query")
        
        # 2. COMPLETENESS: Is response thorough?
        dimensions['completeness'] = self._score_completeness(
            query, response, len(response)
        )
        if dimensions['completeness'] < 0.5:
            flags.append("Response may be incomplete")
        
        # 3. SOURCE ATTRIBUTION: Are sources cited?
        dimensions['source_attribution'] = self._score_attribution(response, context)
        if dimensions['source_attribution'] < 0.3:
            flags.append("Few or no source citations")
        
        # 4. CONFIDENCE: Is appropriate hedging used?
        dimensions['confidence'] = self._score_confidence_appropriateness(
            response, rag_scores
        )
        
        # 5. SPECIFICITY: Are concrete details provided?
        dimensions['specificity'] = self._score_specificity(response)
        if dimensions['specificity'] < 0.4:
            flags.append("Response is vague or generic")
        
        # Calculate overall score (weighted average)
        weights = {
            'relevance': 0.3,
            'completeness': 0.25,
            'source_attribution': 0.2,
            'confidence': 0.15,
            'specificity': 0.1
        }
        
        overall_score = sum(
            dimensions[k] * weights[k]
            for k in weights
        )
        
        # Determine confidence level
        avg_rag_score = sum(rag_scores) / len(rag_scores) if rag_scores else 0
        if avg_rag_score > 0.75 and dimensions['source_attribution'] > 0.7:
            confidence_level = 'high'
        elif avg_rag_score > 0.5 and dimensions['source_attribution'] > 0.4:
            confidence_level = 'medium'
        else:
            confidence_level = 'low'
        
        return {
            'overall_score': overall_score,
            'dimensions': dimensions,
            'flags': flags,
            'confidence_level': confidence_level
        }
    
    def _score_relevance(self, query: str, response: str) -> float:
        """Score how well response addresses query"""
        # Extract key terms from query
        query_terms = set(re.findall(r'\b\w{4,}\b', query.lower()))
        response_lower = response.lower()
        
        # Check what percentage of query terms appear in response
        matched_terms = sum(1 for term in query_terms if term in response_lower)
        
        if len(query_terms) == 0:
            return 1.0
        
        return min(1.0, matched_terms / len(query_terms))
    
    def _score_completeness(self, query: str, response: str, response_length: int) -> float:
        """Score response completeness"""
        # Simple heuristic: length-based with diminishing returns
        # Very short responses (<100 chars) are likely incomplete
        # Very long responses (>2000 chars) don't add much more completeness
        
        if response_length < 100:
            return response_length / 100  # 0-1 based on length
        elif response_length < 2000:
            return 1.0
        else:
            return 1.0  # Cap at 1.0
    
    def _score_attribution(self, response: str, context: str) -> float:
        """Score source attribution"""
        # Count explicit citations
        citation_patterns = [
            r'according to',
            r'as stated in',
            r'from the',
            r'source:',
            r'\(.*?\)',  # Parenthetical citations
            r'document.*states',
        ]
        
        citation_count = sum(
            len(re.findall(pattern, response.lower()))
            for pattern in citation_patterns
        )
        
        # Normalize: 3+ citations = 1.0 score
        return min(1.0, citation_count / 3)
    
    def _score_confidence_appropriateness(self, response: str, rag_scores: List[float]) -> float:
        """Score if confidence matches evidence strength"""
        avg_rag_score = sum(rag_scores) / len(rag_scores) if rag_scores else 0
        
        # Check for hedging language
        hedging_terms = [
            'might', 'may', 'could', 'possibly', 'likely', 'appears',
            'seems', 'suggests', 'indicates', 'unclear', 'limited information'
        ]
        
        hedging_count = sum(
            response.lower().count(term)
            for term in hedging_terms
        )
        
        # Low RAG scores should have hedging, high RAG scores shouldn't need it
        if avg_rag_score < 0.5:
            # Should have hedging
            return min(1.0, hedging_count / 2)
        else:
            # Shouldn't need much hedging
            return max(0.5, 1.0 - (hedging_count * 0.1))
    
    def _score_specificity(self, response: str) -> float:
        """Score response specificity (concrete details vs vague)"""
        # Count specific indicators
        specificity_indicators = {
            'numbers': len(re.findall(r'\b\d+\.?\d*\b', response)),
            'dates': len(re.findall(r'\b\d{1,2}/\d{1,2}/\d{2,4}\b|\d{4}-\d{2}-\d{2}', response)),
            'percentages': len(re.findall(r'\d+\.?\d*%', response)),
            'names': len(re.findall(r'\b[A-Z][a-z]+ [A-Z][a-z]+\b', response)),
        }
        
        total_specific_items = sum(specificity_indicators.values())
        
        # Normalize: 5+ specific items = 1.0 score
        return min(1.0, total_specific_items / 5)
```

---

## 📊 IMPLEMENTATION PLAN FOR CLAUDE CODE

### Phase 1: Core Fixes (Day 1 - 2 hours)

**File**: `core/rag_engine.py`

```python
# Task 1.1: Fix langchain import
# Location: Line 12
# Action: Replace with langchain_core

# Task 1.2: Update requirements.txt
# Add: langchain-core==0.1.23
```

**Verification**:
```bash
python -m py_compile core/rag_engine.py
python -c "from core.rag_engine import UnifiedRAGEngine; print('OK')"
```

---

### Phase 2: Enhanced System Prompt (Day 1 - 4 hours)

**File**: `app/ui.py`

**Task 2.1**: Create new function `build_advanced_system_prompt()`
- Location: Insert before line 1117
- Copy complete implementation from SOLUTION 1 above

**Task 2.2**: Replace existing prompt construction
- Location: Lines 1117-1134
- Replace with:
```python
system_prompt = build_advanced_system_prompt(
    context=context,
    project_metadata=project,
    current_date=current_day,
    conversation_summary=conversation_summarizer.get_summary() if len(conversation_history) > 10 else None
)
```

**Verification**:
```python
# Test in UI
# Ask: "What is the critical path?"
# Expected: Detailed reasoning + definition + application
```

---

### Phase 3: Enhanced Context Building (Day 2 - 3 hours)

**File**: `app/ui.py`

**Task 3.1**: Create `build_enhanced_context()` function
- Location: Insert before line 1103
- Copy implementation from SOLUTION 3

**Task 3.2**: Replace basic context building
- Location: Lines 1103-1125
- Replace with:
```python
context = build_enhanced_context(
    results=results,
    max_tokens=8000,
    include_metadata=True
)
```

**Verification**:
```python
# Check context structure in debug mode
# Should show: Document grouping, scores, metadata
```

---

### Phase 4: Chain-of-Thought Reasoning (Day 2 - 2 hours)

**File**: `app/ui.py`

**Task 4.1**: Create `enable_chain_of_thought()` function
- Location: Insert before line 1160
- Copy implementation from SOLUTION 4

**Task 4.2**: Apply CoT before model call
- Location: Line 1160, before building messages
- Add:
```python
# Detect question type
question_type = detect_question_type(prompt)

# Enable CoT if analytical or recommendation
if question_type in ['analytical', 'recommendation']:
    messages = enable_chain_of_thought(messages, question_type)
```

---

### Phase 5: Conversation Awareness (Day 3 - 3 hours)

**File**: `app/ui.py`

**Task 5.1**: Create conversation-aware context functions
- Location: Insert after context building section
- Copy implementations from SOLUTION 5

**Task 5.2**: Integrate with RAG search
- Location: Before building system prompt
- Add:
```python
context_enhanced = build_conversation_aware_context(
    current_query=prompt,
    conversation_history=history_for_llm,
    rag_results=results
)

# Use enhanced context
context = context_enhanced['primary_context']
if context_enhanced['conversation_context']:
    context = context_enhanced['conversation_context'] + "\n\n" + context
```

---

### Phase 6: Response Quality Scoring (Day 3 - 2 hours)

**File**: Create new `core/response_quality.py`

**Task 6.1**: Implement ResponseQualityScorer
- Copy complete class from SOLUTION 6

**Task 6.2**: Integrate in UI
- Location: After getting LLM response
- Add:
```python
# Score response
from core.response_quality import ResponseQualityScorer
scorer = ResponseQualityScorer()

quality_score = scorer.score_response(
    query=prompt,
    response=assistant_response,
    context=context,
    rag_scores=[r.score for r in results]
)

# Add to metadata
response_metadata['quality_score'] = quality_score['overall_score']
response_metadata['confidence_level'] = quality_score['confidence_level']

# Show warnings if low quality
if quality_score['flags']:
    st.warning("Response quality notes: " + "; ".join(quality_score['flags']))
```

---

### Phase 7: Testing & Validation (Day 4 - Full day)

**Task 7.1**: Unit Tests

```python
# tests/test_advanced_prompt.py

def test_system_prompt_structure():
    """Test that advanced prompt has all sections"""
    prompt = build_advanced_system_prompt(
        context="test",
        project_metadata={'name': 'TEST'},
        current_date="2024-11-21"
    )
    
    # Check all sections present
    assert "Identity & Role" in prompt or "ARGO" in prompt
    assert "Reasoning Protocol" in prompt
    assert "PMO Expertise" in prompt
    assert "Confidence Calibration" in prompt

def test_context_building():
    """Test enhanced context builder"""
    mock_results = [
        SearchResult(content="test1", metadata={'source': 'doc1.pdf'}, score=0.9),
        SearchResult(content="test2", metadata={'source': 'doc1.pdf'}, score=0.8),
        SearchResult(content="test3", metadata={'source': 'doc2.pdf'}, score=0.7),
    ]
    
    context = build_enhanced_context(mock_results)
    
    # Check structure
    assert "DOCUMENT 1" in context
    assert "DOCUMENT 2" in context
    assert "Score:" in context

def test_quality_scoring():
    """Test response quality scorer"""
    scorer = ResponseQualityScorer()
    
    # High quality response
    response_good = """According to the Project Charter, the baseline budget is $450M. 
    The project completion date is March 15, 2026 as stated in Schedule Rev 23."""
    
    score_good = scorer.score_response(
        query="What is the budget?",
        response=response_good,
        context="Project Charter: Budget: $450M",
        rag_scores=[0.9, 0.85]
    )
    
    assert score_good['overall_score'] > 0.7
    assert score_good['confidence_level'] == 'high'
    
    # Low quality response
    response_bad = "It might be around that amount."
    
    score_bad = scorer.score_response(
        query="What is the budget?",
        response=response_bad,
        context="",
        rag_scores=[0.3]
    )
    
    assert score_bad['overall_score'] < 0.5
```

**Task 7.2**: Integration Tests

```python
# tests/test_end_to_end.py

def test_complete_query_flow():
    """Test complete query from input to response"""
    # Initialize system
    components = initialize_argo()
    
    # Simulate query
    query = "What is the project completion date?"
    
    # Get RAG results
    results, metadata = components['rag_engine'].search(query, top_k=5)
    
    # Build context
    context = build_enhanced_context(results)
    
    # Build prompt
    system_prompt = build_advanced_system_prompt(
        context=context,
        project_metadata=components['project'],
        current_date="2024-11-21"
    )
    
    # Verify prompt quality
    assert len(system_prompt) > 1000  # Should be comprehensive
    assert "PMO" in system_prompt
    assert "Reasoning" in system_prompt
    
    print("✓ End-to-end flow successful")
```

**Task 7.3**: Performance Benchmarks

```python
# tests/test_performance.py

import time

def test_context_building_performance():
    """Ensure context building is fast"""
    mock_results = [SearchResult(...) for _ in range(20)]
    
    start = time.time()
    context = build_enhanced_context(mock_results)
    duration = time.time() - start
    
    assert duration < 0.5  # Should complete in <500ms

def test_quality_scoring_performance():
    """Ensure quality scoring is fast"""
    scorer = ResponseQualityScorer()
    
    start = time.time()
    score = scorer.score_response(query="test", response="test"*100, context="", rag_scores=[0.8])
    duration = time.time() - start
    
    assert duration < 0.2  # Should complete in <200ms
```

---

## 🎯 EXPECTED OUTCOMES

### Intelligence Improvements

**Before** (Current System):
```
User: "What is the critical path?"
ARGO: "The critical path is the sequence of activities with zero float."
```

**After** (Enhanced System):
```
User: "What is the critical path?"
ARGO: "Analysis of Current Project Schedule:

The critical path represents the sequence of dependent activities that determines 
the minimum project duration. For our PALLAS reactor project:

Critical Path Details (from Schedule Rev 23):
• Total Duration: 823 days
• Critical Activities: 387 out of 4,832 total (8%)
• Key Milestones on Critical Path:
  - Reactor Vessel Installation (45 days)
  - Primary Loop Commissioning (60 days)
  - Containment Structure Pour (90 days)

Current Status:
• Critical Path Length Index (CPLI): 0.974 (Very high - 97.4% of total duration)
• This indicates limited schedule flexibility

Risk Assessment:
⚠️ With 8% of activities critical, any delay in these activities directly 
impacts project completion. Industry benchmark is 5-10% critical activities.

Recommendation:
Focus resources on activities A120, A145, and A089 (highest drag values).
Consider fast-tracking commissioning phase if delays occur.

Source: Project Schedule Rev 23, dated 2024-10-15
Confidence: High (information directly from schedule data)"""
```

### Metrics to Track

| Metric | Current | Target | Measurement |
|--------|---------|--------|-------------|
| Response Relevance | ~60% | >85% | User feedback |
| Source Attribution | ~30% | >70% | Automatic scoring |
| Confidence Calibration | Poor | Good | Quality scorer |
| PMO Terminology | Limited | Extensive | Term usage analysis |
| Multi-step Reasoning | No | Yes | CoT detection |
| Response Length (avg) | 150 words | 300-500 words | Word count |

---

## ⚠️ CRITICAL REQUIREMENTS

### For Claude Code

1. **PRESERVE all existing functionality**
   - Do NOT remove any working features
   - Do NOT break backwards compatibility
   - Do NOT change file structure without approval

2. **TEST everything**
   - Run all tests before committing
   - Verify UI still loads
   - Check that chat still works

3. **DOCUMENT changes**
   - Add docstrings to all new functions
   - Update README if needed
   - Create CHANGELOG entry

4. **ASK before major decisions**
   - If unsure about approach, ask
   - If breaking change needed, ask
   - If new dependency needed, ask

---

## 📦 DELIVERABLES CHECKLIST

### Phase 1 Complete When:
- [ ] No langchain warnings
- [ ] All imports work
- [ ] Tests pass

### Phase 2 Complete When:
- [ ] New system prompt function exists
- [ ] Old prompt replaced
- [ ] Responses show reasoning
- [ ] PMO terminology used correctly

### Phase 3 Complete When:
- [ ] Context shows document grouping
- [ ] Context shows relevance scores
- [ ] Context properly formatted

### Phase 4 Complete When:
- [ ] Analytical questions show reasoning steps
- [ ] CoT improves response quality (A/B test)

### Phase 5 Complete When:
- [ ] Follow-up questions work better
- [ ] System remembers conversation context
- [ ] Entity extraction works

### Phase 6 Complete When:
- [ ] Quality scores appear in metadata
- [ ] Low quality responses flagged
- [ ] Confidence levels accurate

### Phase 7 Complete When:
- [ ] All unit tests pass
- [ ] Integration tests pass
- [ ] Performance acceptable
- [ ] No regressions

---

## 🚀 READY FOR IMPLEMENTATION

This document provides complete specifications for enhancing ARGO's core intelligence. 

**Next Steps**:
1. Claude Code reads this document
2. Implements Phase 1 (fixes)
3. We review together
4. Continues with Phases 2-7
5. Iterate on feedback

**Estimated Total Time**: 4 days of focused implementation

---

END OF TECHNICAL SPECIFICATION
